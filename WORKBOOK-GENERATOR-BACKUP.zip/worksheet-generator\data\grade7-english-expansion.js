// Additional Grade 7 English Topics
// To be integrated into main curriculum.js

const grade7EnglishExpansion = {
    "Persuasive Writing": {
        title: "Writing to Persuade and Argue",
        curriculumCode: "7e2 - Writing",
        overallExpectation: "write persuasive texts to convince readers of a position",
        workbook: [
            {
                lessonNumber: 1,
                lessonTitle: "Elements of Persuasive Writing",
                tutorial: "# Persuasive Writing\n\n## Purpose\n\nTo convince readers to agree with your opinion or take action.\n\n## Key Elements\n\n**1. CLAIM (Thesis)**\n- Your main argument\n- Clear position statement\n- Example: 'Schools should start later in the morning.'\n\n**2. REASONS**\n- Why your claim is true\n- At least 3 strong reasons\n- Example: 'Teens need more sleep for health.'\n\n**3. EVIDENCE**\n- Facts, statistics, expert quotes\n- Supports your reasons\n- Example: 'Studies show teens need 9 hours of sleep.'\n\n**4. COUNTERARGUMENT**\n- Acknowledge opposing view\n- Then refute it\n- Example: 'Some say it's inconvenient, BUT student health is more important.'\n\n**5. CALL TO ACTION**\n- Tell readers what to do\n- Example: 'Contact the school board today!'\n\n## Persuasive Techniques\n\n**Appeals:**\n- **Logos** (Logic): Facts, statistics, logical reasoning\n- **Pathos** (Emotion): Stories, vivid language, emotional connection\n- **Ethos** (Credibility): Expert opinions, personal experience\n\n**Language:**\n- Strong verbs: must, should, need to\n- Rhetorical questions: 'Don't you want...?'\n- Repetition for emphasis\n- Powerful adjectives",
                keyTerms: ["Persuasive Writing", "Claim", "Evidence", "Counterargument", "Logos", "Pathos", "Ethos"],
                examples: [
                    {
                        problem: "Write a claim for why students should have longer lunch breaks",
                        solution: "Students should have 45-minute lunch breaks to improve health and academic performance.",
                        steps: ["1. State clear position", "2. Include topic (lunch breaks)", "3. Give brief reason (health/academics)", "4. Make it debatable"]
                    }
                ],
                practice: [
                    { text: "Write a claim about school uniforms (for or against)", space: 60 },
                    { text: "Give 3 reasons supporting: 'Homework should be limited to 30 minutes per night'", space: 100 },
                    { text: "Write a counterargument to: 'Video games are bad for students'", space: 90 }
                ]
            }
        ]
    },
    "Literary Devices": {
        title: "Understanding Literary Devices and Figurative Language",
        curriculumCode: "7e1 - Reading",
        overallExpectation: "identify and analyze literary devices in texts",
        workbook: [
            {
                lessonNumber: 1,
                lessonTitle: "Common Literary Devices",
                tutorial: "# Literary Devices\n\n## What are Literary Devices?\n\nTools authors use to create meaning and effect.\n\n## Major Devices\n\n**1. SIMILE**\n- Comparison using 'like' or 'as'\n- Example: 'She was as brave as a lion.'\n- Example: 'He ran like the wind.'\n\n**2. METAPHOR**\n- Direct comparison (no 'like' or 'as')\n- Example: 'Time is money.'\n- Example: 'Her smile was sunshine.'\n\n**3. PERSONIFICATION**\n- Giving human qualities to non-human things\n- Example: 'The wind whispered through the trees.'\n- Example: 'The sun smiled down on us.'\n\n**4. HYPERBOLE**\n- Extreme exaggeration\n- Example: 'I'm so hungry I could eat a horse!'\n- Example: 'This bag weighs a ton!'\n\n**5. ALLITERATION**\n- Repetition of beginning sounds\n- Example: 'Peter Piper picked a peck...'\n- Example: 'Sally sells seashells...'\n\n**6. ONOMATOPOEIA**\n- Words that sound like what they mean\n- Example: 'buzz', 'crash', 'sizzle', 'boom'\n\n**7. IMAGERY**\n- Descriptive language appealing to senses\n- Sight, sound, smell, taste, touch\n- Example: 'The crisp, golden leaves crunched underfoot.'\n\n## Why Authors Use Them\n\n- Create vivid images\n- Make writing more interesting\n- Express ideas creatively\n- Engage readers emotionally",
                keyTerms: ["Simile", "Metaphor", "Personification", "Hyperbole", "Alliteration", "Imagery"],
                examples: [
                    {
                        problem: "Identify the device: 'The classroom was a zoo!'",
                        solution: "Metaphor (compares classroom to zoo without 'like' or 'as')",
                        steps: ["1. Look for comparison", "2. No 'like' or 'as'", "3. Direct comparison = metaphor"]
                    }
                ],
                practice: [
                    { text: "Write a simile comparing a student to an animal", space: 60 },
                    { text: "Give an example of personification using 'the moon'", space: 70 },
                    { text: "Identify the device: 'I've told you a million times!' What device?", space: 60 },
                    { text: "Write a sentence using alliteration with the letter 'B'", space: 70 }
                ]
            }
        ]
    },
    "Grammar - Complex Sentences": {
        title: "Writing Complex and Compound Sentences",
        curriculumCode: "7e3 - Language Conventions",
        overallExpectation: "use complex and compound sentence structures correctly",
        workbook: [
            {
                lessonNumber: 1,
                lessonTitle: "Sentence Types and Structure",
                tutorial: "# Sentence Structure\n\n## Four Sentence Types\n\n**1. SIMPLE SENTENCE**\n- One independent clause\n- Example: 'The dog barked.'\n- Example: 'Sarah and Tom went to the park.'\n\n**2. COMPOUND SENTENCE**\n- Two independent clauses joined\n- Use: FANBOYS (for, and, nor, but, or, yet, so)\n- Example: 'I wanted pizza, but she wanted pasta.'\n- Example: 'He studied hard, so he passed the test.'\n\n**3. COMPLEX SENTENCE**\n- Independent clause + dependent clause\n- Use: subordinating conjunctions\n- Example: 'Because it was raining, we stayed inside.'\n- Example: 'She smiled when she saw her friend.'\n\n**4. COMPOUND-COMPLEX**\n- 2+ independent + 1+ dependent\n- Example: 'When it rained, we stayed inside, and we watched movies.'\n\n## Subordinating Conjunctions\n\n**Time:** when, while, after, before, until, since\n**Cause:** because, since, as\n**Condition:** if, unless, provided that\n**Contrast:** although, though, even though, whereas\n\n## Punctuation Rules\n\n**Compound:**\n- Comma before FANBOYS\n- Example: 'I ran, and she walked.'\n\n**Complex:**\n- Comma if dependent clause comes first\n- Example: 'If you study, you will pass.'\n- No comma if independent comes first\n- Example: 'You will pass if you study.'",
                keyTerms: ["Simple Sentence", "Compound Sentence", "Complex Sentence", "Independent Clause", "Dependent Clause", "FANBOYS"],
                examples: [
                    {
                        problem: "Combine using 'because': 'It was cold. I wore a jacket.'",
                        solution: "Because it was cold, I wore a jacket. OR I wore a jacket because it was cold.",
                        steps: ["1. Identify cause (it was cold)", "2. Identify effect (wore jacket)", "3. Use 'because' to connect", "4. Add comma if 'because' clause comes first"]
                    }
                ],
                practice: [
                    { text: "Combine with 'and': 'She studied hard. She passed the test.'", space: 70 },
                    { text: "Combine with 'although': 'It was raining. We went outside.'", space: 70 },
                    { text: "Write a complex sentence using 'when'", space: 70 },
                    { text: "Identify sentence type: 'I like pizza, but my sister prefers pasta.'", space: 60 }
                ]
            }
        ]
    },
    "Research Skills": {
        title: "Research and Information Literacy",
        curriculumCode: "7e1 - Reading/Media Literacy",
        overallExpectation: "use research skills to gather, evaluate, and use information",
        workbook: [
            {
                lessonNumber: 1,
                lessonTitle: "Evaluating Sources",
                tutorial: "# Research Skills\n\n## Finding Reliable Sources\n\n### CRAAP Test for Evaluating Sources\n\n**C - CURRENCY**\n- When was it published?\n- Is the information up-to-date?\n- Are links working?\n\n**R - RELEVANCE**\n- Does it answer your question?\n- Is it at the right level?\n- Who is the intended audience?\n\n**A - AUTHORITY**\n- Who is the author?\n- What are their credentials?\n- Is it published by a reputable organization?\n\n**A - ACCURACY**\n- Is information supported by evidence?\n- Can you verify it elsewhere?\n- Are there errors?\n\n**P - PURPOSE**\n- Why was it written?\n- To inform, persuade, sell, entertain?\n- Is there bias?\n\n## Types of Sources\n\n**Primary Sources:**\n- Original documents\n- Examples: diaries, letters, interviews, photographs\n- Firsthand accounts\n\n**Secondary Sources:**\n- Analyze/interpret primary sources\n- Examples: textbooks, articles, documentaries\n- Secondhand accounts\n\n## Avoiding Plagiarism\n\n**What is Plagiarism?**\n- Using someone's words/ideas without credit\n- Copying and pasting\n- Not citing sources\n\n**How to Avoid:**\n1. Take notes in your own words\n2. Use quotation marks for exact words\n3. Cite all sources\n4. Create a bibliography",
                keyTerms: ["Research", "Source", "CRAAP Test", "Primary Source", "Secondary Source", "Plagiarism", "Citation"],
                examples: [
                    {
                        problem: "Is Wikipedia a reliable source for a research project?",
                        solution: "Not as a final source, but good for starting research and finding other sources",
                        steps: ["1. Check CRAAP test", "2. Anyone can edit (authority issue)", "3. Good for overview", "4. Use references at bottom for better sources"]
                    }
                ],
                practice: [
                    { text: "Give 3 examples of primary sources about World War II", space: 80 },
                    { text: "Why is it important to check when a source was published?", space: 80 },
                    { text: "What's the difference between paraphrasing and plagiarizing?", space: 90 }
                ]
            }
        ]
    },
    "Poetry Analysis": {
        title: "Understanding and Analyzing Poetry",
        curriculumCode: "7e1 - Reading",
        overallExpectation: "read and analyze various forms of poetry",
        workbook: [
            {
                lessonNumber: 1,
                lessonTitle: "Elements of Poetry",
                tutorial: "# Poetry Analysis\n\n## What Makes Poetry Different?\n\n- Condensed language\n- Figurative language\n- Sound and rhythm\n- Line breaks and stanzas\n- Emotional expression\n\n## Key Elements\n\n**1. SPEAKER**\n- Voice in the poem (not always the poet)\n- Who is talking?\n\n**2. THEME**\n- Central message or idea\n- What is the poem about?\n- Examples: love, nature, loss, hope\n\n**3. TONE**\n- Author's attitude\n- Examples: sad, joyful, angry, nostalgic\n\n**4. MOOD**\n- Feeling created for reader\n- How does it make you feel?\n\n**5. IMAGERY**\n- Descriptive language\n- Appeals to five senses\n\n**6. SOUND DEVICES**\n- **Rhyme:** Words that sound alike\n- **Rhythm:** Pattern of beats\n- **Repetition:** Repeated words/phrases\n- **Alliteration:** Repeated beginning sounds\n\n**7. STRUCTURE**\n- **Stanza:** Group of lines (like a paragraph)\n- **Line breaks:** Where lines end\n- **Form:** Haiku, sonnet, free verse, etc.\n\n## How to Analyze a Poem\n\n**Step 1:** Read it multiple times\n**Step 2:** Look up unfamiliar words\n**Step 3:** Identify speaker and situation\n**Step 4:** Find figurative language\n**Step 5:** Determine theme\n**Step 6:** Analyze how form supports meaning",
                keyTerms: ["Poetry", "Speaker", "Theme", "Tone", "Mood", "Imagery", "Stanza", "Rhyme"],
                examples: [
                    {
                        problem: "What is the theme of a poem about a flower growing through concrete?",
                        solution: "Perseverance, resilience, overcoming obstacles, hope",
                        steps: ["1. What is literally happening? (flower growing)", "2. What does it represent? (overcoming difficulty)", "3. What's the message? (perseverance)"]
                    }
                ],
                practice: [
                    { text: "What's the difference between tone and mood?", space: 80 },
                    { text: "Find a poem and identify 2 examples of imagery", space: 100 },
                    { text: "Write a 4-line poem about nature using one simile", space: 90 }
                ]
            }
        ]
    }
};

// Export for integration
if (typeof module !== 'undefined' && module.exports) {
    module.exports = grade7EnglishExpansion;
}
