// Comprehensive Ontario Curriculum Workbook Data - Grades 5-8
// Aligned with Ontario Mathematics and Science Curriculum

const curriculumData = {
    "5": {
        "Mathematics": {
            "Number Sense - Place Value": {
                title: "Place Value and Whole Numbers to 100,000",
                curriculumCode: "5m1 - Number Sense and Numeration",
                overallExpectation: "read, represent, compare, and order whole numbers to 100,000, decimal numbers to hundredths, and simple fractions",
                workbook: [
                    {
                        lessonNumber: 1,
                        lessonTitle: "Place Value to 100,000",
                        tutorial: "# Place Value\n\n## Understanding Place Value\n\nEvery digit in a number has a VALUE based on its PLACE.\n\n**Example: 45,678**\n- 4 is in the TEN THOUSANDS place = 40,000\n- 5 is in the THOUSANDS place = 5,000\n- 6 is in the HUNDREDS place = 600\n- 7 is in the TENS place = 70\n- 8 is in the ONES place = 8\n\n**Expanded Form:** 40,000 + 5,000 + 600 + 70 + 8\n\n**Word Form:** Forty-five thousand, six hundred seventy-eight",
                        keyTerms: ["Place Value", "Expanded Form", "Word Form", "Standard Form"],
                        examples: [
                            {
                                problem: "Write 67,234 in expanded form",
                                solution: "60,000 + 7,000 + 200 + 30 + 4",
                                steps: ["1. Identify each digit's place value", "2. 6 is in ten thousands = 60,000", "3. 7 is in thousands = 7,000", "4. Write as sum: 60,000 + 7,000 + 200 + 30 + 4"]
                            }
                        ],
                        practice: [
                            { text: "Write 83,456 in expanded form", space: 50 },
                            { text: "Write ninety-two thousand, four hundred fifteen in standard form", space: 50 },
                            { text: "What is the value of the 7 in 37,891?", space: 40 }
                        ]
                    }
                ]
            },
            "Decimal Numbers": {
                title: "Understanding Decimals to Hundredths",
                curriculumCode: "5m1 - Number Sense and Numeration",
                overallExpectation: "demonstrate an understanding of place value in whole numbers and decimal numbers from 0.01 to 100,000",
                workbook: [
                    {
                        lessonNumber: 1,
                        lessonTitle: "Decimal Place Value",
                        tutorial: "# Decimal Numbers\n\n## Place Value for Decimals\n\nDecimals represent parts of whole numbers.\n\n**Example: 3.45**\n- 3 is in the ONES place\n- 4 is in the TENTHS place (4/10 or 0.4)\n- 5 is in the HUNDREDTHS place (5/100 or 0.05)\n\n## Reading Decimals\n\n3.45 is read as \"three and forty-five hundredths\"\n\n## Comparing Decimals\n\nLine up the decimal points and compare digit by digit from left to right.",
                        keyTerms: ["Decimal", "Tenths", "Hundredths", "Decimal Point"],
                        examples: [
                            {
                                problem: "Compare: Which is greater, 0.7 or 0.68?",
                                solution: "0.7 is greater",
                                steps: ["1. Write with same decimal places: 0.70 and 0.68", "2. Compare: 70 hundredths vs 68 hundredths", "3. Since 70 > 68, then 0.7 > 0.68"]
                            }
                        ],
                        practice: [
                            { text: "Write 0.35 in words", space: 50 },
                            { text: "Compare using <, >, or =: 0.8 ___ 0.75", space: 40 },
                            { text: "Order from least to greatest: 0.6, 0.06, 0.66", space: 50 }
                        ]
                    }
                ]
            },
            "Multiplication and Division": {
                title: "Multiplying and Dividing Whole Numbers",
                curriculumCode: "5m1 - Number Sense and Numeration",
                overallExpectation: "solve problems involving the multiplication and division of multi-digit whole numbers, and involving the addition and subtraction of decimal numbers to hundredths",
                workbook: [
                    {
                        lessonNumber: 1,
                        lessonTitle: "Multi-Digit Multiplication",
                        tutorial: "# Multiplication Strategies\n\n## Standard Algorithm\n\nMultiply from right to left, carrying when needed.\n\n**Example: 43 × 26**\n\n```\n   43\n × 26\n ----\n  258  (43 × 6)\n 860   (43 × 20)\n----\n1118\n```\n\n## Estimation\n\nRound numbers first to check if your answer is reasonable.\n\n40 × 30 = 1200 (close to 1118 ✓)",
                        keyTerms: ["Multiplication", "Algorithm", "Partial Products", "Estimation"],
                        examples: [
                            {
                                problem: "Calculate: 34 × 12",
                                solution: "408",
                                steps: ["1. Multiply 34 × 2 = 68", "2. Multiply 34 × 10 = 340", "3. Add: 68 + 340 = 408"]
                            }
                        ],
                        practice: [
                            { text: "Calculate: 56 × 14", space: 80 },
                            { text: "Calculate: 123 × 25", space: 80 },
                            { text: "A box holds 24 books. How many books in 15 boxes?", space: 80 }
                        ]
                    },
                    {
                        lessonNumber: 2,
                        lessonTitle: "Long Division",
                        tutorial: "# Division\n\n## Long Division Steps\n\n1. **Divide:** How many times does divisor go into first digits?\n2. **Multiply:** Multiply divisor by that number\n3. **Subtract:** Subtract from the dividend\n4. **Bring down:** Bring down next digit\n5. **Repeat:** Until no digits left\n\n**Example: 156 ÷ 12 = 13**\n\n```\n    13\n  -----\n12│156\n   12↓\n   ---\n    36\n    36\n   ---\n     0\n```",
                        keyTerms: ["Division", "Divisor", "Dividend", "Quotient", "Remainder"],
                        examples: [
                            {
                                problem: "Calculate: 144 ÷ 12",
                                solution: "12",
                                steps: ["1. 12 goes into 14 once (1 × 12 = 12)", "2. Subtract: 14 - 12 = 2", "3. Bring down 4 to make 24", "4. 12 goes into 24 twice (2 × 12 = 24)", "5. Answer: 12"]
                            }
                        ],
                        practice: [
                            { text: "Calculate: 168 ÷ 14", space: 80 },
                            { text: "Calculate: 225 ÷ 15", space: 80 },
                            { text: "156 cookies shared equally among 12 students. How many each?", space: 80 }
                        ]
                    }
                ]
            },
            "Fractions": {
                title: "Introduction to Fractions",
                curriculumCode: "5m1 - Number Sense and Numeration",
                overallExpectation: "demonstrate an understanding of fractions by using concrete materials to represent, compare, and order simple fractions",
                workbook: [
                    {
                        lessonNumber: 1,
                        lessonTitle: "Understanding Fractions",
                        tutorial: "# Fractions\n\n## What is a Fraction?\n\nA fraction shows PART of a WHOLE.\n\n**Parts of a Fraction:**\n- **Numerator** (top): How many parts you have\n- **Denominator** (bottom): How many equal parts in the whole\n\n**Example: 3/4**\n- Numerator: 3 (you have 3 parts)\n- Denominator: 4 (whole divided into 4 equal parts)\n\n## Equivalent Fractions\n\nFractions that represent the same amount:\n\n1/2 = 2/4 = 3/6 = 4/8\n\nMultiply or divide both numerator and denominator by the same number.",
                        keyTerms: ["Fraction", "Numerator", "Denominator", "Equivalent", "Simplify"],
                        examples: [
                            {
                                problem: "Find an equivalent fraction for 2/3",
                                solution: "4/6 (or 6/9, 8/12, etc.)",
                                steps: ["1. Choose a number to multiply by (let's use 2)", "2. Multiply numerator: 2 × 2 = 4", "3. Multiply denominator: 3 × 2 = 6", "4. Answer: 4/6"]
                            }
                        ],
                        practice: [
                            { text: "Write two equivalent fractions for 1/2", space: 50 },
                            { text: "Simplify: 6/8", space: 50 },
                            { text: "Compare using <, >, or =: 2/3 ___ 3/4", space: 60 }
                        ]
                    }
                ]
            },
            "Measurement - Perimeter and Area": {
                title: "Perimeter, Area, and Volume",
                curriculumCode: "5m3 - Measurement",
                overallExpectation: "estimate, measure, and record perimeter, area, temperature change, and elapsed time",
                workbook: [
                    {
                        lessonNumber: 1,
                        lessonTitle: "Perimeter of Rectangles",
                        tutorial: "# Perimeter\n\n## What is Perimeter?\n\nThe total DISTANCE around the outside of a shape.\n\n## Formula for Rectangle\n\nPerimeter = 2 × length + 2 × width\n\nOR\n\nPerimeter = length + length + width + width\n\n**Example:**\n\nRectangle: length = 8 cm, width = 3 cm\n\nP = 2(8) + 2(3) = 16 + 6 = 22 cm",
                        keyTerms: ["Perimeter", "Length", "Width", "Distance", "Formula"],
                        examples: [
                            {
                                problem: "Find perimeter: length = 12m, width = 5m",
                                solution: "34m",
                                steps: ["1. Formula: P = 2 × length + 2 × width", "2. P = 2(12) + 2(5)", "3. P = 24 + 10 = 34m"]
                            }
                        ],
                        practice: [
                            { text: "Find perimeter of rectangle: 15cm × 7cm", space: 60 },
                            { text: "A square has sides of 9m. What is its perimeter?", space: 60 },
                            { text: "A garden is 20m long and 12m wide. How much fencing is needed?", space: 80 }
                        ]
                    },
                    {
                        lessonNumber: 2,
                        lessonTitle: "Area of Rectangles",
                        tutorial: "# Area\n\n## What is Area?\n\nThe amount of space INSIDE a 2D shape.\n\nMeasured in square units (cm², m², etc.)\n\n## Formula for Rectangle\n\nArea = length × width\n\n**Example:**\n\nRectangle: length = 8 cm, width = 3 cm\n\nA = 8 × 3 = 24 cm²",
                        keyTerms: ["Area", "Square Units", "Length", "Width"],
                        examples: [
                            {
                                problem: "Find area: length = 12m, width = 5m",
                                solution: "60 m²",
                                steps: ["1. Formula: A = length × width", "2. A = 12 × 5", "3. A = 60 m²"]
                            }
                        ],
                        practice: [
                            { text: "Find area of rectangle: 15cm × 7cm", space: 60 },
                            { text: "A square has sides of 9m. What is its area?", space: 60 },
                            { text: "Which has greater area: 10×6 rectangle or 8×8 square?", space: 80 }
                        ]
                    }
                ]
            },
            "Data Management": {
                title: "Graphs and Data Analysis",
                curriculumCode: "5m4 - Data Management and Probability",
                overallExpectation: "collect and organize categorical or discrete primary data and display the data using charts and graphs",
                workbook: [
                    {
                        lessonNumber: 1,
                        lessonTitle: "Reading and Creating Graphs",
                        tutorial: "# Data and Graphs\n\n## Types of Graphs\n\n**Bar Graph:**\n- Shows data with bars\n- Good for comparing categories\n- Each bar represents a category\n\n**Line Graph:**\n- Shows change over time\n- Points connected by lines\n- Good for trends\n\n**Pictograph:**\n- Uses pictures/symbols\n- Each symbol = certain number\n- Need a key!\n\n## Reading Graphs\n\n1. Read the title\n2. Check the labels (x-axis and y-axis)\n3. Look at the scale\n4. Interpret the data",
                        keyTerms: ["Graph", "Bar Graph", "Line Graph", "Data", "Scale", "Axis"],
                        examples: [
                            {
                                problem: "Look at a bar graph showing favorite sports. If soccer has 15 votes and basketball has 12, how many more chose soccer?",
                                solution: "3 more students",
                                steps: ["1. Find soccer bar: 15 students", "2. Find basketball bar: 12 students", "3. Subtract: 15 - 12 = 3", "4. Answer: 3 more students chose soccer"]
                            }
                        ],
                        practice: [
                            { text: "Create a bar graph showing: Apples: 8, Bananas: 12, Oranges: 6", space: 150 },
                            { text: "What information do you need to include in every graph?", space: 80 }
                        ]
                    }
                ]
            }
        },
        "Science": {
            "Human Organ Systems": {
                title: "Human Body Systems",
                curriculumCode: "5s1 - Life Systems",
                overallExpectation: "investigate the structure and function of the major organs of the human body",
                workbook: [
                    {
                        lessonNumber: 1,
                        lessonTitle: "The Digestive System",
                        tutorial: "# The Digestive System\n\n## Function\n\nBreaks down food so our body can use it for energy and growth.\n\n## Major Organs (in order)\n\n- **Mouth:** Chewing and saliva begin digestion\n- **Esophagus:** Tube that carries food to stomach\n- **Stomach:** Acids and muscles break down food\n- **Small Intestine:** Absorbs nutrients into bloodstream\n- **Large Intestine:** Absorbs water, forms waste\n\n## Process\n\n1. Food enters mouth\n2. Chewed and mixed with saliva\n3. Travels through esophagus\n4. Broken down in stomach (2-4 hours)\n5. Nutrients absorbed in small intestine\n6. Water absorbed in large intestine\n7. Waste eliminated",
                        keyTerms: ["Digestion", "Nutrients", "Absorption", "Organs", "Enzymes"],
                        examples: [
                            {
                                problem: "What happens to food in the stomach?",
                                solution: "Stomach acids and muscles break down food into liquid",
                                steps: ["1. Food enters from esophagus", "2. Stomach acid mixes with food", "3. Stomach muscles churn", "4. Food becomes liquid (chyme)"]
                            }
                        ],
                        practice: [
                            { text: "List the organs food passes through in order", space: 80 },
                            { text: "Describe the function of the small intestine", space: 70 },
                            { text: "Why is digestion important for your body?", space: 80 }
                        ]
                    }
                ]
            },
            "Properties of Matter": {
                title: "Understanding Properties and Changes in Matter",
                curriculumCode: "5s2 - Matter and Energy",
                overallExpectation: "investigate the properties of and changes in matter",
                workbook: [
                    {
                        lessonNumber: 1,
                        lessonTitle: "States of Matter",
                        tutorial: "# States of Matter\n\n## Three States\n\n**1. SOLID**\n- Particles tightly packed\n- Definite shape and volume\n- Examples: ice, wood, metal\n\n**2. LIQUID**\n- Particles loosely packed\n- No definite shape, definite volume\n- Takes shape of container\n- Examples: water, milk, juice\n\n**3. GAS**\n- Particles far apart\n- No definite shape or volume\n- Fills entire container\n- Examples: air, steam, oxygen\n\n## Changes of State\n\n- **Melting:** Solid → Liquid (heat)\n- **Freezing:** Liquid → Solid (cool)\n- **Evaporation:** Liquid → Gas (heat)\n- **Condensation:** Gas → Liquid (cool)",
                        keyTerms: ["Solid", "Liquid", "Gas", "Melting", "Evaporation", "Matter"],
                        examples: [
                            {
                                problem: "What happens to water when it freezes?",
                                solution: "It changes from liquid to solid (ice)",
                                steps: ["1. Water is cooled below 0°C", "2. Particles slow down and pack together", "3. Water becomes ice (solid)"]
                            }
                        ],
                        practice: [
                            { text: "Give 3 examples of liquids", space: 60 },
                            { text: "What state of matter is steam?", space: 50 },
                            { text: "Describe what happens when ice melts", space: 80 }
                        ]
                    }
                ]
            }
        },
        "English": {
            "Reading Strategies": {
                title: "Reading Comprehension Strategies",
                curriculumCode: "5e1 - Reading",
                overallExpectation: "read and demonstrate comprehension of texts using various reading comprehension strategies",
                workbook: [
                    {
                        lessonNumber: 1,
                        lessonTitle: "Making Predictions",
                        tutorial: "# Making Predictions\n\n## What is Predicting?\n\nGuessing what will happen next using clues from the text.\n\n## How to Make Good Predictions\n\n**Use 3 Types of Clues:**\n\n1. **Text Clues**\n- What has happened so far?\n- What do characters say/do?\n\n2. **Picture Clues**\n- What do illustrations show?\n- What details are important?\n\n3. **Your Knowledge**\n- What do you already know?\n- What usually happens in similar situations?\n\n## Steps to Predict\n\n1. Stop and think while reading\n2. Look for clues\n3. Make a guess\n4. Read on to check prediction\n5. Adjust if needed",
                        keyTerms: ["Prediction", "Clues", "Inference", "Text Evidence"],
                        examples: [
                            {
                                problem: "Text says: 'Dark clouds gathered. Wind picked up.' What might happen?",
                                solution: "It will probably rain/storm",
                                steps: ["1. Text clue: dark clouds, wind", "2. My knowledge: this happens before storms", "3. Prediction: storm coming"]
                            }
                        ],
                        practice: [
                            { text: "What clues help you make predictions?", space: 80 },
                            { text: "Why is predicting important when reading?", space: 80 },
                            { text: "Make a prediction: 'Sarah studied hard all week. Test day arrived...'", space: 80 }
                        ]
                    }
                ]
            },
            "Grammar - Parts of Speech": {
                title: "Understanding Parts of Speech",
                curriculumCode: "5e3 - Language Conventions",
                overallExpectation: "identify and use parts of speech correctly in writing and speaking",
                workbook: [
                    {
                        lessonNumber: 1,
                        lessonTitle: "Nouns and Verbs",
                        tutorial: "# Parts of Speech\n\n## What are Parts of Speech?\n\nWords are grouped into categories based on their job in a sentence.\n\n## Nouns\n\n**Definition:** Person, place, thing, or idea\n\n**Types:**\n- **Common nouns:** general (dog, city, book)\n- **Proper nouns:** specific names (Fido, Toronto, Harry Potter)\n- **Concrete nouns:** can touch/see (chair, apple)\n- **Abstract nouns:** ideas/feelings (love, freedom, happiness)\n\n## Verbs\n\n**Definition:** Action words or state of being\n\n**Types:**\n- **Action verbs:** run, jump, write, think\n- **Linking verbs:** am, is, are, was, were, seem\n- **Helping verbs:** will, can, should, have\n\n## Finding Them in Sentences\n\n**Example:** The happy dog ran quickly.\n- Nouns: dog\n- Verbs: ran",
                        keyTerms: ["Noun", "Verb", "Proper Noun", "Common Noun", "Action Verb"],
                        examples: [
                            {
                                problem: "Identify the nouns and verbs: 'Sarah plays tennis every Saturday.'",
                                solution: "Nouns: Sarah (proper), tennis (common), Saturday (proper). Verb: plays",
                                steps: ["1. Find people/places/things = Sarah, tennis, Saturday", "2. Find action word = plays", "3. Sarah and Saturday are proper (capitalized)"]
                            }
                        ],
                        practice: [
                            { text: "Circle all nouns: The cat climbed the tall tree in our backyard.", space: 60 },
                            { text: "Underline all verbs: Maria reads books and writes stories.", space: 60 },
                            { text: "Write 3 proper nouns and 3 common nouns", space: 80 }
                        ]
                    },
                    {
                        lessonNumber: 2,
                        lessonTitle: "Adjectives and Adverbs",
                        tutorial: "# Adjectives and Adverbs\n\n## Adjectives\n\n**Definition:** Describe nouns (tell WHAT KIND, HOW MANY, WHICH ONE)\n\n**Examples:**\n- The **red** car (what kind)\n- **Five** cookies (how many)\n- **That** book (which one)\n\n## Adverbs\n\n**Definition:** Describe verbs, adjectives, or other adverbs (tell HOW, WHEN, WHERE, HOW MUCH)\n\n**Many end in -ly:**\n- She sang **beautifully** (how)\n- Come **here** (where)\n- We left **yesterday** (when)\n- It's **very** cold (how much)\n\n## Quick Test\n\nAdjective questions: What kind? How many? Which?\nAdverb questions: How? When? Where?",
                        keyTerms: ["Adjective", "Adverb", "Describe", "Modify"],
                        examples: [
                            {
                                problem: "Find adjectives and adverbs: 'The small puppy barked loudly.'",
                                solution: "Adjective: small (describes puppy). Adverb: loudly (describes how it barked)",
                                steps: ["1. Find describing word for noun 'puppy' = small", "2. Find word telling HOW it barked = loudly"]
                            }
                        ],
                        practice: [
                            { text: "Add 2 adjectives: The ___ cat sat on the ___ mat.", space: 60 },
                            { text: "Add 2 adverbs: She ___ ran ___ to catch the bus.", space: 60 },
                            { text: "Write a sentence with 2 adjectives and 1 adverb", space: 80 }
                        ]
                    }
                ]
            },
            "Vocabulary Development": {
                title: "Building Vocabulary Skills",
                curriculumCode: "5e1 - Reading",
                overallExpectation: "use strategies to determine the meaning of unfamiliar words",
                workbook: [
                    {
                        lessonNumber: 1,
                        lessonTitle: "Context Clues",
                        tutorial: "# Using Context Clues\n\n## What are Context Clues?\n\nHints in the sentence or paragraph that help you figure out unknown words.\n\n## Types of Context Clues\n\n**1. Definition Clue**\n- Word is defined in the sentence\n- Example: 'A herbivore, an animal that eats plants, lives here.'\n\n**2. Synonym Clue**\n- Similar word nearby\n- Example: 'The huge, gigantic elephant...'\n\n**3. Antonym Clue**\n- Opposite word gives hint\n- Example: 'Unlike her timid sister, Sarah was brave.'\n\n**4. Example Clue**\n- Examples help explain\n- Example: 'Utensils like forks, spoons, and knives...'\n\n## Strategy\n\n1. Read whole sentence\n2. Look for clue words: like, such as, means, unlike, but\n3. Use clues to guess meaning\n4. Check if it makes sense",
                        keyTerms: ["Context Clues", "Definition", "Synonym", "Antonym"],
                        examples: [
                            {
                                problem: "What does 'famished' mean? 'After not eating all day, I was famished and ready for dinner.'",
                                solution: "Very hungry",
                                steps: ["1. Context: 'not eating all day' and 'ready for dinner'", "2. These suggest being very hungry", "3. Famished = very hungry"]
                            }
                        ],
                        practice: [
                            { text: "Use context: 'The arid desert had no water for miles.'", space: 70 },
                            { text: "Use context: 'She was elated, jumping with joy and smiling.'", space: 70 },
                            { text: "Write a sentence using context clues for the word 'gigantic'", space: 80 }
                        ]
                    },
                    {
                        lessonNumber: 2,
                        lessonTitle: "Prefixes and Suffixes",
                        tutorial: "# Word Parts\n\n## Prefixes (Beginning)\n\nAdded to the START of a root word to change meaning.\n\n**Common Prefixes:**\n- **un-** = not (unhappy = not happy)\n- **re-** = again (rewrite = write again)\n- **pre-** = before (preview = view before)\n- **dis-** = not/opposite (disagree = not agree)\n- **mis-** = wrong (misspell = spell wrong)\n\n## Suffixes (Ending)\n\nAdded to the END of a root word.\n\n**Common Suffixes:**\n- **-ful** = full of (careful = full of care)\n- **-less** = without (hopeless = without hope)\n- **-er** = one who (teacher = one who teaches)\n- **-able** = can be (readable = can be read)\n\n## Strategy\n\n1. Find the root word\n2. Identify prefix or suffix\n3. Put meanings together",
                        keyTerms: ["Prefix", "Suffix", "Root Word", "Word Parts"],
                        examples: [
                            {
                                problem: "What does 'uncomfortable' mean?",
                                solution: "Not comfortable",
                                steps: ["1. Root word: comfort (at ease)", "2. Prefix: un- (not)", "3. Suffix: -able (can be)", "4. Together: not able to be comfortable"]
                            }
                        ],
                        practice: [
                            { text: "Add prefix: ___heat means to heat again", space: 50 },
                            { text: "Add suffix: care___ means full of care", space: 50 },
                            { text: "What does 'disagreeable' mean? Break it into parts.", space: 80 }
                        ]
                    }
                ]
            },
            "Narrative Writing": {
                title: "Writing Stories and Narratives",
                curriculumCode: "5e2 - Writing",
                overallExpectation: "write narrative texts with well-developed characters and plot",
                workbook: [
                    {
                        lessonNumber: 1,
                        lessonTitle: "Story Structure",
                        tutorial: "# Elements of a Story\n\n## Story Structure\n\nEvery good story has a BEGINNING, MIDDLE, and END.\n\n**BEGINNING (Introduction)**\n- Introduce characters\n- Describe setting (when/where)\n- Start the action\n\n**MIDDLE (Rising Action & Climax)**\n- Problem or conflict develops\n- Events happen\n- Tension builds\n- Climax = most exciting part\n\n**END (Resolution)**\n- Problem is solved\n- Loose ends tied up\n- Conclusion\n\n## Plot Diagram\n\n```\n        Climax\n       /     \\\n     /         \\\n   /             \\\nBeginning        End\n```",
                        keyTerms: ["Plot", "Beginning", "Middle", "End", "Climax", "Resolution"],
                        examples: [
                            {
                                problem: "Identify story parts: 'Tom found a map. He followed it through the forest. At the old tree, he discovered buried treasure. Tom was rich!'",
                                solution: "Beginning: found map. Middle: followed through forest. Climax: discovered treasure. End: became rich",
                                steps: ["1. Beginning introduces situation", "2. Middle describes journey", "3. Climax is discovery", "4. End wraps up"]
                            }
                        ],
                        practice: [
                            { text: "Plan a story: Write beginning, middle, and end for a story about a lost pet", space: 120 },
                            { text: "What makes a good story ending?", space: 70 }
                        ]
                    },
                    {
                        lessonNumber: 2,
                        lessonTitle: "Character and Dialogue",
                        tutorial: "# Bringing Stories to Life\n\n## Creating Characters\n\n**What to Include:**\n- Name\n- Age/appearance\n- Personality traits\n- What they want (goals)\n- How they speak/act\n\n**Show, Don't Tell:**\n- WEAK: 'She was nervous.'\n- STRONG: 'Her hands shook as she walked to the stage.'\n\n## Writing Dialogue\n\n**Rules:**\n1. Use quotation marks around spoken words\n2. Start new paragraph for each speaker\n3. Add dialogue tags (he said, she asked)\n4. Use commas correctly\n\n**Example:**\n'I'm scared,' whispered Tom.\n'Don't worry,' replied Sarah. 'I'll help you.'\n\n## Make It Sound Real\n\nPeople don't always speak in complete sentences. They use contractions and casual language.",
                        keyTerms: ["Character", "Dialogue", "Quotation Marks", "Dialogue Tags"],
                        examples: [
                            {
                                problem: "Fix the dialogue: Tom said I am hungry.\nLet's eat replied Sarah.",
                                solution: "'I am hungry,' said Tom.\n'Let's eat!' replied Sarah.",
                                steps: ["1. Add quotation marks around speech", "2. Add commas before dialogue tags", "3. Capitalize first word in quotes"]
                            }
                        ],
                        practice: [
                            { text: "Write a dialogue between two friends planning a surprise party (4-6 lines)", space: 120 },
                            { text: "Describe a character without using the word 'nice'", space: 80 }
                        ]
                    }
                ]
            },
            "Main Idea and Details": {
                title: "Finding Main Ideas and Supporting Details",
                curriculumCode: "5e1 - Reading",
                overallExpectation: "identify main ideas and supporting details in texts",
                workbook: [
                    {
                        lessonNumber: 1,
                        lessonTitle: "Identifying Main Ideas",
                        tutorial: "# Main Idea vs. Details\n\n## What is the Main Idea?\n\nThe MOST IMPORTANT point the author wants you to understand.\n\n**Think:** What is this mostly about?\n\n## Where to Find It\n\n**Often in:**\n- First sentence (topic sentence)\n- Last sentence (conclusion)\n- Repeated throughout\n\n**Not Always Stated!**\nSometimes you must figure it out from clues.\n\n## Supporting Details\n\nFacts, examples, and descriptions that SUPPORT the main idea.\n\n**Example Paragraph:**\n'Dogs make great pets. They are loyal and loving. They protect your home. Dogs provide companionship and fun.'\n\n- MAIN IDEA: Dogs make great pets\n- DETAILS: loyal, loving, protective, provide companionship\n\n## Test It\n\nCover details. Does main idea still make sense? ✓\nCover main idea. Do details tell the whole story? ✗",
                        keyTerms: ["Main Idea", "Supporting Details", "Topic Sentence", "Evidence"],
                        examples: [
                            {
                                problem: "Find main idea: 'Recycling helps Earth. It reduces waste in landfills. Recycling saves energy. It also conserves natural resources.'",
                                solution: "Main idea: Recycling helps Earth. Details: reduces waste, saves energy, conserves resources",
                                steps: ["1. What is this about? Recycling", "2. What about recycling? It helps Earth", "3. Other sentences support this idea"]
                            }
                        ],
                        practice: [
                            { text: "Main idea: 'Soccer is popular worldwide. It's played in over 200 countries. Millions watch the World Cup. Many kids play soccer in school.'", space: 80 },
                            { text: "Write a paragraph with main idea 'Exercise is important' and 3 details", space: 100 }
                        ]
                    }
                ]
            },
            "Sentence Structure": {
                title: "Building Strong Sentences",
                curriculumCode: "5e3 - Language Conventions",
                overallExpectation: "construct complete and varied sentences",
                workbook: [
                    {
                        lessonNumber: 1,
                        lessonTitle: "Complete Sentences",
                        tutorial: "# What Makes a Sentence Complete?\n\n## Two Essential Parts\n\n**1. Subject (WHO or WHAT)**\n- The person, place, or thing doing the action\n- Example: **The dog** barked.\n\n**2. Predicate (WHAT HAPPENS)**\n- The action or state of being\n- Example: The dog **barked loudly**.\n\n## Complete vs. Fragment\n\n**COMPLETE:** The cat climbed the tree.\n- Has subject (cat) and predicate (climbed the tree) ✓\n\n**FRAGMENT:** Climbed the tree.\n- Missing subject - WHO climbed? ✗\n\n**FRAGMENT:** The cat in the yard.\n- Missing predicate - What did cat DO? ✗\n\n## Capital and Period\n\nEvery sentence must:\n- Start with capital letter\n- End with punctuation (. ! ?)",
                        keyTerms: ["Subject", "Predicate", "Complete Sentence", "Fragment"],
                        examples: [
                            {
                                problem: "Is this complete? 'Running in the park.'",
                                solution: "No - it's a fragment. Missing subject (WHO is running?)",
                                steps: ["1. Look for subject - not there!", "2. Look for complete predicate - starts with -ing verb", "3. Fragment - needs subject"]
                            }
                        ],
                        practice: [
                            { text: "Fix this fragment: 'The happy children'", space: 60 },
                            { text: "Fix this fragment: 'Played soccer after school'", space: 60 },
                            { text: "Circle the subject and underline the predicate: 'My sister loves reading books.'", space: 70 }
                        ]
                    },
                    {
                        lessonNumber: 2,
                        lessonTitle: "Types of Sentences",
                        tutorial: "# Four Types of Sentences\n\n## 1. Statement (Declarative)\n\n**Purpose:** Tell information\n**Punctuation:** Period (.)\n**Example:** I like pizza.\n\n## 2. Question (Interrogative)\n\n**Purpose:** Ask something\n**Punctuation:** Question mark (?)\n**Example:** Do you like pizza?\n\n## 3. Command (Imperative)\n\n**Purpose:** Give order/direction\n**Punctuation:** Period (.)\n**Example:** Eat your pizza.\n\n## 4. Exclamation (Exclamatory)\n\n**Purpose:** Show strong feeling\n**Punctuation:** Exclamation mark (!)\n**Example:** This pizza is amazing!\n\n## Varying Your Writing\n\nGood writers use ALL types of sentences to make writing interesting!",
                        keyTerms: ["Statement", "Question", "Command", "Exclamation", "Punctuation"],
                        examples: [
                            {
                                problem: "What type: 'Watch out!'",
                                solution: "Exclamation (shows strong feeling) or Command (gives direction)",
                                steps: ["1. Has strong feeling? Yes (warning)", "2. Has exclamation mark? Yes", "3. Could be both!"]
                            }
                        ],
                        practice: [
                            { text: "Write a statement about your favorite book", space: 60 },
                            { text: "Write a question about homework", space: 60 },
                            { text: "Write a command and an exclamation about the same topic", space: 80 }
                        ]
                    }
                ]
            },
            "Oral Communication": {
                title: "Speaking and Listening Skills",
                curriculumCode: "5e4 - Oral Communication",
                overallExpectation: "communicate orally for a variety of purposes using appropriate language and tone",
                workbook: [
                    {
                        lessonNumber: 1,
                        lessonTitle: "Effective Presentations",
                        tutorial: "# Giving a Good Presentation\n\n## Before You Speak\n\n**Prepare:**\n1. Know your topic well\n2. Organize your ideas\n3. Practice out loud\n4. Time yourself\n5. Prepare visual aids (if needed)\n\n## During Your Presentation\n\n**Voice:**\n- Speak clearly and loudly enough\n- Don't rush - pause between ideas\n- Use expression (not monotone!)\n- Change pace for emphasis\n\n**Body Language:**\n- Stand up straight\n- Make eye contact\n- Use hand gestures naturally\n- Face your audience\n- Don't fidget\n\n**Content:**\n- Start with introduction\n- Have clear main points (2-3)\n- Use examples\n- End with conclusion\n\n## Dealing with Nerves\n\n- Take deep breaths\n- Remember everyone gets nervous\n- Focus on your message\n- Practice makes perfect!",
                        keyTerms: ["Presentation", "Eye Contact", "Volume", "Pace", "Body Language"],
                        examples: [
                            {
                                problem: "What should you do if you forget what to say during a presentation?",
                                solution: "Pause, take a breath, look at your notes, or summarize what you just said before continuing",
                                steps: ["1. Don't panic", "2. Pause briefly", "3. Check notes or recap", "4. Continue confidently"]
                            }
                        ],
                        practice: [
                            { text: "Plan a 1-minute presentation about your favorite hobby. List 3 main points.", space: 100 },
                            { text: "Why is eye contact important when speaking?", space: 70 },
                            { text: "List 3 ways to make your voice more interesting", space: 80 }
                        ]
                    },
                    {
                        lessonNumber: 2,
                        lessonTitle: "Active Listening",
                        tutorial: "# Being a Good Listener\n\n## What is Active Listening?\n\nFully concentrating on what is being said, not just hearing words.\n\n## How to Listen Actively\n\n**Look at the Speaker:**\n- Face them\n- Make eye contact\n- Show you're paying attention\n\n**Show You're Listening:**\n- Nod your head\n- Smile or react appropriately\n- Don't interrupt\n\n**Focus:**\n- Don't let mind wander\n- Don't plan what you'll say next\n- Don't play with things\n- Turn off distractions\n\n**Respond:**\n- Ask questions\n- Make comments\n- Summarize what you heard\n\n## Why It Matters\n\n- Shows respect\n- Helps you learn\n- Improves relationships\n- Prevents misunderstandings\n\n## Bad Listening Habits to Avoid\n\n- Interrupting\n- Looking at phone/device\n- Talking to someone else\n- Making distracting noises\n- Thinking about other things",
                        keyTerms: ["Active Listening", "Attention", "Eye Contact", "Respect"],
                        examples: [
                            {
                                problem: "Your friend is telling you about their weekend, but you keep looking at your phone. What's wrong?",
                                solution: "Not practicing active listening - phone is distraction, not giving full attention",
                                steps: ["1. Phone takes attention away", "2. Shows disrespect to friend", "3. You'll miss what they're saying", "4. Put phone away"]
                            }
                        ],
                        practice: [
                            { text: "List 4 ways to show you're actively listening", space: 80 },
                            { text: "Why is interrupting rude?", space: 70 },
                            { text: "Write about a time when someone wasn't listening to you. How did it feel?", space: 100 }
                        ]
                    }
                ]
            }
        },
        "Science": {
            "Forces and Motion": {
                title: "Understanding Forces and Motion",
                curriculumCode: "5s3 - Structures and Mechanisms",
                overallExpectation: "investigate forces and motion, and identify ways in which they are applied in everyday life",
                workbook: [
                    {
                        lessonNumber: 1,
                        lessonTitle: "Types of Forces",
                        tutorial: "# Forces\n\n## What is a Force?\n\nA force is a PUSH or a PULL that can change how an object moves.\n\n## Types of Forces\n\n**1. Gravity**\n- Pulls objects toward Earth\n- Makes things fall down\n- Gives us weight\n\n**2. Friction**\n- Slows moving objects\n- Happens when surfaces rub together\n- Example: Brakes on a bike\n\n**3. Magnetic Force**\n- Attracts or repels magnets\n- Works without touching\n\n**4. Applied Force**\n- Force you apply yourself\n- Pushing a cart, throwing a ball\n\n## Measuring Force\n\n- Unit: Newtons (N)\n- More force = bigger change in motion",
                        keyTerms: ["Force", "Gravity", "Friction", "Newtons", "Motion"],
                        examples: [
                            {
                                problem: "What force stops a rolling ball?",
                                solution: "Friction",
                                steps: ["1. Ball is rolling - has motion", "2. Eventually stops - motion changes", "3. Friction between ball and ground slows it down"]
                            }
                        ],
                        practice: [
                            { text: "Name 3 forces you used today", space: 80 },
                            { text: "Why do we need friction? Give 2 examples.", space: 90 },
                            { text: "Draw an object with arrows showing forces acting on it", space: 100 }
                        ]
                    }
                ]
            },
            "Conservation of Energy": {
                title: "Energy and Its Transformations",
                curriculumCode: "5s2 - Matter and Energy",
                overallExpectation: "demonstrate an understanding of the various forms of energy and how energy can be transformed",
                workbook: [
                    {
                        lessonNumber: 1,
                        lessonTitle: "Forms of Energy",
                        tutorial: "# Energy\n\n## What is Energy?\n\nEnergy is the ability to do work or cause change.\n\n## Forms of Energy\n\n**1. Light Energy**\n- From the sun, light bulbs\n- Helps us see\n\n**2. Heat Energy (Thermal)**\n- Makes things warm\n- From sun, fire, friction\n\n**3. Sound Energy**\n- From vibrations\n- Music, voices, noises\n\n**4. Electrical Energy**\n- Powers devices\n- Flows through wires\n\n**5. Mechanical Energy**\n- Energy of motion\n- Moving car, spinning wheel\n\n## Energy Transformation\n\nEnergy changes from one form to another!\n\n**Examples:**\n- Light bulb: Electrical → Light + Heat\n- Solar panel: Light → Electrical\n- Microphone: Sound → Electrical",
                        keyTerms: ["Energy", "Transformation", "Thermal", "Mechanical", "Electrical"],
                        examples: [
                            {
                                problem: "What energy transformations happen when you turn on a flashlight?",
                                solution: "Chemical energy (battery) → Electrical energy → Light energy",
                                steps: ["1. Battery has chemical energy stored", "2. Converts to electrical energy when switched on", "3. Electrical flows to bulb", "4. Bulb converts to light (and some heat)"]
                            }
                        ],
                        practice: [
                            { text: "Name all forms of energy you can find in your classroom", space: 90 },
                            { text: "Describe the energy transformations in a toaster", space: 80 },
                            { text: "Why is energy important in our daily lives?", space: 100 }
                        ]
                    }
                ]
            },
            "Respiratory and Circulatory Systems": {
                title: "How Body Systems Work Together",
                curriculumCode: "5s1 - Life Systems",
                overallExpectation: "investigate the structure and function of the respiratory and circulatory systems",
                workbook: [
                    {
                        lessonNumber: 1,
                        lessonTitle: "The Respiratory System",
                        tutorial: "# Breathing and the Respiratory System\n\n## Why Do We Breathe?\n\nTo get OXYGEN into our body and remove CARBON DIOXIDE\n\n## Parts of the Respiratory System\n\n**1. Nose/Mouth**\n- Air enters here\n- Nose warms and filters air\n\n**2. Trachea (Windpipe)**\n- Tube connecting throat to lungs\n- Protected by rings of cartilage\n\n**3. Bronchi**\n- Two tubes branching from trachea\n- One to each lung\n\n**4. Lungs**\n- Main organs for breathing\n- Contain millions of tiny air sacs (alveoli)\n- Where oxygen enters blood\n\n**5. Diaphragm**\n- Muscle below lungs\n- Contracts to pull air in\n- Relaxes to push air out\n\n## The Process\n\n1. **Inhale:** Breathe oxygen IN\n2. **Gas Exchange:** Oxygen enters blood, CO₂ leaves\n3. **Exhale:** Breathe carbon dioxide OUT",
                        keyTerms: ["Oxygen", "Carbon Dioxide", "Lungs", "Trachea", "Diaphragm", "Alveoli"],
                        examples: [
                            {
                                problem: "Why do you breathe faster when you exercise?",
                                solution: "Your muscles need more oxygen to produce energy during exercise",
                                steps: ["1. Exercise requires energy", "2. Energy needs oxygen", "3. Breathing faster brings more oxygen to muscles", "4. Removes CO₂ faster too"]
                            }
                        ],
                        practice: [
                            { text: "Trace the path of oxygen from your nose to your lungs", space: 90 },
                            { text: "What happens to your diaphragm when you breathe in?", space: 70 },
                            { text: "Why is it important to breathe through your nose?", space: 80 }
                        ]
                    },
                    {
                        lessonNumber: 2,
                        lessonTitle: "The Circulatory System",
                        tutorial: "# The Circulatory System\n\n## What Does It Do?\n\nMoves blood throughout your body to deliver oxygen and nutrients\n\n## Main Parts\n\n**1. Heart**\n- Muscular pump\n- 4 chambers\n- Beats about 100,000 times per day!\n\n**2. Blood Vessels**\n\n*Arteries:*\n- Carry blood AWAY from heart\n- Thick walls (high pressure)\n- Carry oxygen-rich blood\n\n*Veins:*\n- Carry blood BACK to heart\n- Thinner walls\n- Carry blood low in oxygen\n\n*Capillaries:*\n- Tiny vessels\n- Connect arteries to veins\n- Where gas/nutrient exchange happens\n\n**3. Blood**\n- Red blood cells: Carry oxygen\n- White blood cells: Fight disease\n- Platelets: Help blood clot\n- Plasma: Liquid part\n\n## How They Work Together\n\nRespiratory + Circulatory = Oxygen Delivery System!\n\n1. Lungs add oxygen to blood\n2. Heart pumps oxygen-rich blood\n3. Blood travels through arteries\n4. Capillaries deliver oxygen to cells\n5. Veins return blood to heart\n6. Heart pumps blood back to lungs",
                        keyTerms: ["Heart", "Arteries", "Veins", "Capillaries", "Blood"],
                        examples: [
                            {
                                problem: "Why does your heart beat faster when you run?",
                                solution: "To pump more oxygen-rich blood to your working muscles",
                                steps: ["1. Running muscles need lots of oxygen", "2. Heart beats faster to pump more blood", "3. More blood = more oxygen delivered", "4. Removes waste products faster"]
                            }
                        ],
                        practice: [
                            { text: "What's the difference between arteries and veins?", space: 80 },
                            { text: "Describe how blood travels from your heart to your hand and back", space: 100 },
                            { text: "Why is the heart called a 'pump'?", space: 70 }
                        ]
                    }
                ]
            },
            "Weather and Climate": {
                title: "Understanding Weather Patterns",
                curriculumCode: "5s4 - Earth and Space Systems",
                overallExpectation: "investigate weather patterns and the water cycle",
                workbook: [
                    {
                        lessonNumber: 1,
                        lessonTitle: "The Water Cycle",
                        tutorial: "# The Water Cycle\n\n## What Is It?\n\nThe continuous movement of water on, above, and below Earth's surface.\n\n## Four Main Stages\n\n**1. Evaporation**\n- Heat from sun warms water\n- Liquid water becomes water vapor (gas)\n- Happens from oceans, lakes, rivers\n\n**2. Condensation**\n- Water vapor cools in the air\n- Changes back to liquid drops\n- Forms clouds\n\n**3. Precipitation**\n- Water falls from clouds\n- Forms: Rain, snow, sleet, hail\n- Returns water to Earth\n\n**4. Collection**\n- Water collects in oceans, lakes, rivers\n- Soaks into ground (groundwater)\n- Cycle begins again\n\n## Why It Matters\n\n- Provides fresh water\n- Affects weather\n- Supports all life on Earth\n- Never creates or destroys water - just moves it!",
                        keyTerms: ["Evaporation", "Condensation", "Precipitation", "Water Cycle", "Groundwater"],
                        examples: [
                            {
                                problem: "What happens to a puddle on a sunny day?",
                                solution: "It evaporates - the water turns into water vapor and goes into the air",
                                steps: ["1. Sun heats the puddle", "2. Water molecules gain energy", "3. Turn from liquid to gas (evaporation)", "4. Water vapor rises into air", "5. Puddle gets smaller and disappears"]
                            }
                        ],
                        practice: [
                            { text: "Draw and label the water cycle", space: 120 },
                            { text: "Why don't we run out of water if we keep using it?", space: 80 },
                            { text: "What role does the sun play in the water cycle?", space: 80 }
                        ]
                    }
                ]
            }
        },
        "Social Studies": {
            "Early Peoples of Canada": {
                title: "First Nations Before European Contact",
                curriculumCode: "5h1 - Heritage and Identity",
                overallExpectation: "describe significant aspects of the daily lives of First Nations peoples in Canada around 1500",
                workbook: [
                    {
                        lessonNumber: 1,
                        lessonTitle: "Indigenous Cultures and Lifestyles",
                        tutorial: "# First Nations Before Europeans Arrived\n\n## Who Were They?\n\nIndigenous peoples lived in Canada for thousands of years before Europeans arrived.\n\n## Different Nations, Different Ways of Life\n\n**Location Affects Lifestyle**\n\nWhere people lived determined how they lived.\n\n**1. East Coast (Woodland)**\n- Mi'kmaq, Haudenosaunee\n- Forests and rivers\n- Hunted deer, fished\n- Grew corn, beans, squash ('Three Sisters')\n- Built longhouses\n\n**2. Plains**\n- Blackfoot, Cree\n- Grasslands\n- Followed buffalo herds\n- Used teepees (easy to move)\n\n**3. West Coast**\n- Haida, Kwakwaka'wakw\n- Ocean and forests\n- Fished salmon\n- Built totem poles\n- Cedar plank houses\n\n**4. North (Arctic)**\n- Inuit\n- Cold tundra\n- Hunted seals, caribou, whales\n- Built igloos in winter\n\n## Respect for Nature\n\nAll First Nations peoples:\n- Lived in harmony with nature\n- Only took what they needed\n- Used every part of animals\n- Passed on knowledge through oral traditions",
                        keyTerms: ["First Nations", "Indigenous", "Oral Traditions", "Sustainable", "Culture"],
                        examples: [
                            {
                                problem: "Why did Plains peoples use teepees while East Coast peoples used longhouses?",
                                solution: "Plains peoples followed buffalo and needed homes they could move easily (teepees). East Coast peoples stayed in one place to farm, so they built permanent longhouses.",
                                steps: ["1. Plains lifestyle: Following buffalo herds meant moving often", "2. Teepees: Light, portable, quick to set up", "3. East Coast lifestyle: Farming required staying in one place", "4. Longhouses: Permanent, large, housed many families"]
                            }
                        ],
                        practice: [
                            { text: "How did location affect the lifestyle of First Nations peoples? Give 2 examples.", space: 100 },
                            { text: "What were the 'Three Sisters' and why were they important?", space: 80 },
                            { text: "How did First Nations peoples show respect for nature?", space: 90 }
                        ]
                    }
                ]
            },
            "Roles and Responsibilities": {
                title: "Citizenship and Government",
                curriculumCode: "5c1 - People and Environments",
                overallExpectation: "identify and describe fundamental rights and responsibilities associated with citizenship",
                workbook: [
                    {
                        lessonNumber: 1,
                        lessonTitle: "Being a Good Citizen",
                        tutorial: "# Rights and Responsibilities\n\n## What is a Citizen?\n\nA member of a community, country, or nation who has both RIGHTS and RESPONSIBILITIES.\n\n## Rights (Things You Can Do)\n\n**In Canada, citizens have the right to:**\n- Freedom of speech (express opinions)\n- Freedom of religion\n- Vote (when 18+)\n- Fair treatment under the law\n- Education\n- Safety and security\n\n## Responsibilities (Things You Should Do)\n\n**Good citizens should:**\n- **Obey laws**\n  - Follow rules that keep everyone safe\n  \n- **Vote**\n  - Participate in elections (when old enough)\n  \n- **Respect others**\n  - Treat everyone fairly\n  - Respect different cultures and beliefs\n  \n- **Help the community**\n  - Volunteer\n  - Take care of public spaces\n  \n- **Be informed**\n  - Learn about issues\n  - Make good decisions\n\n## Rights Come With Responsibilities\n\nYour rights are protected when everyone does their responsibilities!\n\n**Example:** You have the right to safety. Everyone has the responsibility to follow laws that keep others safe.",
                        keyTerms: ["Citizen", "Rights", "Responsibilities", "Democracy", "Community"],
                        examples: [
                            {
                                problem: "You see litter in your local park. As a good citizen, what should you do?",
                                solution: "Pick it up and put it in a garbage bin - taking responsibility to keep public spaces clean",
                                steps: ["1. Recognize the problem: Litter harms the environment", "2. Remember responsibility: Care for public spaces", "3. Take action: Pick up litter properly", "4. Result: Cleaner, safer park for everyone"]
                            }
                        ],
                        practice: [
                            { text: "List 3 rights and 3 responsibilities of Canadian citizens", space: 100 },
                            { text: "Why is voting an important responsibility?", space: 80 },
                            { text: "How can you be a good citizen at school?", space: 90 }
                        ]
                    }
                ]
            },
            "Economic Systems": {
                title: "Understanding Economics",
                curriculumCode: "5c2 - People and Environments",
                overallExpectation: "identify and describe Canada's economic connections with other parts of the world",
                workbook: [
                    {
                        lessonNumber: 1,
                        lessonTitle: "Needs, Wants, and Choices",
                        tutorial: "# Basic Economics\n\n## Needs vs. Wants\n\n**NEEDS**\n- Things you MUST have to survive\n- Examples: Food, water, shelter, clothing\n- Basic and essential\n\n**WANTS**\n- Things you WOULD LIKE but don't need\n- Examples: Toys, candy, video games, newest phone\n- Extra and optional\n\n## Why Can't We Have Everything?\n\n**SCARCITY**\n- Resources are limited\n- We don't have unlimited money, time, or materials\n- Must make choices!\n\n## Making Economic Choices\n\n**Opportunity Cost:** What you GIVE UP when you choose something\n\n**Example:**\n- You have $10\n- Choice A: Buy a book ($10)\n- Choice B: Buy a toy ($10)\n- If you buy the book, the opportunity cost is the toy you didn't get\n\n## Goods and Services\n\n**GOODS**\n- Physical items you can touch\n- Examples: Food, clothes, books\n\n**SERVICES**\n- Actions people do for others\n- Examples: Teaching, haircuts, medical care\n\n## Producers and Consumers\n\n**PRODUCERS:** Make goods or provide services\n**CONSUMERS:** Buy goods or use services\n\n*You can be both!*",
                        keyTerms: ["Needs", "Wants", "Scarcity", "Opportunity Cost", "Goods", "Services"],
                        examples: [
                            {
                                problem: "You get $20 for your birthday. You want a $15 game and a $12 book. What's your opportunity cost if you choose the book?",
                                solution: "The opportunity cost is the game, because you can't afford both",
                                steps: ["1. Total money: $20", "2. Game costs $15, book costs $12", "3. Total if you buy both: $27 (too much!)", "4. Choose book ($12)", "5. Opportunity cost = game you gave up"]
                            }
                        ],
                        practice: [
                            { text: "List 5 needs and 5 wants from your daily life", space: 100 },
                            { text: "Are you a producer, consumer, or both? Explain.", space: 80 },
                            { text: "Describe a choice you made this week and its opportunity cost", space: 100 }
                        ]
                    }
                ]
            }
        }
    },
    "6": {
        "Mathematics": {
            "Fractions Operations": {
                title: "Adding and Subtracting Fractions",
                curriculumCode: "6m1 - Number Sense and Numeration",
                overallExpectation: "demonstrate an understanding of relationships between fractions, decimals, and percents, and solve problems involving fractions",
                workbook: [
                    {
                        lessonNumber: 1,
                        lessonTitle: "Adding Fractions with Like Denominators",
                        tutorial: "# Adding Fractions\n\n## Like Denominators (Same Bottom Number)\n\n**Rule:** Add the numerators, keep the denominator\n\n**Example:** 2/5 + 1/5 = 3/5\n\n- Add tops: 2 + 1 = 3\n- Keep bottom: 5\n- Answer: 3/5\n\n## Steps\n\n1. Check denominators are the same\n2. Add numerators\n3. Keep denominator\n4. Simplify if possible",
                        keyTerms: ["Addition", "Like Denominators", "Numerator", "Simplify"],
                        examples: [
                            {
                                problem: "3/8 + 2/8",
                                solution: "5/8",
                                steps: ["1. Same denominator (8)", "2. Add numerators: 3 + 2 = 5", "3. Keep denominator: 8", "4. Answer: 5/8"]
                            }
                        ],
                        practice: [
                            { text: "2/7 + 3/7", space: 50 },
                            { text: "1/4 + 2/4", space: 50 },
                            { text: "Sarah ate 2/8 of a pizza. Tom ate 3/8. What fraction did they eat together?", space: 80 }
                        ]
                    },
                    {
                        lessonNumber: 2,
                        lessonTitle: "Adding Fractions with Unlike Denominators",
                        tutorial: "# Unlike Denominators (Different Bottom Numbers)\n\n## Steps to Add\n\n1. Find common denominator (LCD)\n2. Convert both fractions\n3. Add numerators\n4. Keep new denominator\n5. Simplify\n\n**Example:** 1/2 + 1/3\n\n1. LCD of 2 and 3 is 6\n2. Convert: 1/2 = 3/6 and 1/3 = 2/6\n3. Add: 3/6 + 2/6 = 5/6",
                        keyTerms: ["Unlike Denominators", "Common Denominator", "LCD"],
                        examples: [
                            {
                                problem: "1/4 + 1/6",
                                solution: "5/12",
                                steps: ["1. LCD of 4 and 6 is 12", "2. 1/4 = 3/12", "3. 1/6 = 2/12", "4. 3/12 + 2/12 = 5/12"]
                            }
                        ],
                        practice: [
                            { text: "1/3 + 1/4", space: 80 },
                            { text: "2/5 + 1/2", space: 80 },
                            { text: "Maria walked 1/2 km, then 1/4 km. Total distance?", space: 80 }
                        ]
                    }
                ]
            },
            "Multiplying Fractions and Decimals": {
                title: "Multiplication of Fractions and Decimals",
                curriculumCode: "6m1 - Number Sense and Numeration",
                overallExpectation: "solve problems involving the multiplication and division of decimal numbers to thousandths",
                workbook: [
                    {
                        lessonNumber: 1,
                        lessonTitle: "Multiplying Fractions",
                        tutorial: "# Multiplying Fractions\n\n## The Rule\n\n**Multiply tops, multiply bottoms!**\n\n## Steps\n\n1. Multiply numerators\n2. Multiply denominators\n3. Simplify\n\n**Example:** 2/3 × 1/4 = 2/12 = 1/6\n\n- Multiply tops: 2 × 1 = 2\n- Multiply bottoms: 3 × 4 = 12\n- Simplify: 2/12 = 1/6",
                        keyTerms: ["Multiplication", "Numerator", "Denominator", "Simplify"],
                        examples: [
                            {
                                problem: "3/4 × 2/5",
                                solution: "6/20 = 3/10",
                                steps: ["1. Multiply numerators: 3 × 2 = 6", "2. Multiply denominators: 4 × 5 = 20", "3. Simplify: 6/20 = 3/10"]
                            }
                        ],
                        practice: [
                            { text: "1/2 × 1/3", space: 60 },
                            { text: "2/3 × 3/4", space: 60 },
                            { text: "A recipe needs 2/3 cup flour. You're making 1/2 the recipe. How much flour?", space: 80 }
                        ]
                    },
                    {
                        lessonNumber: 2,
                        lessonTitle: "Multiplying Decimals",
                        tutorial: "# Multiplying Decimals\n\n## Steps\n\n1. Ignore decimal points and multiply\n2. Count total decimal places in both numbers\n3. Put decimal point in answer\n\n**Example:** 2.5 × 1.2\n\n1. Multiply: 25 × 12 = 300\n2. Count decimals: 1 + 1 = 2 places\n3. Answer: 3.00 = 3.0",
                        keyTerms: ["Decimal", "Multiplication", "Decimal Places"],
                        examples: [
                            {
                                problem: "3.4 × 2.1",
                                solution: "7.14",
                                steps: ["1. Multiply: 34 × 21 = 714", "2. Count decimal places: 1 + 1 = 2", "3. Place decimal: 7.14"]
                            }
                        ],
                        practice: [
                            { text: "1.5 × 2.4", space: 60 },
                            { text: "0.8 × 0.6", space: 60 },
                            { text: "A book costs $12.50. Sales tax is 1.13 times the price. What's the total?", space: 80 }
                        ]
                    }
                ]
            },
            "Ratios and Proportions": {
                title: "Understanding Ratios and Rates",
                curriculumCode: "6m1 - Number Sense and Numeration",
                overallExpectation: "demonstrate an understanding of the relationship between ratios and fractions",
                workbook: [
                    {
                        lessonNumber: 1,
                        lessonTitle: "Introduction to Ratios",
                        tutorial: "# Ratios\n\n## What is a Ratio?\n\nA comparison of two quantities.\n\n## Ways to Write Ratios\n\n- Using words: \"3 to 5\"\n- Using colon: 3:5\n- As fraction: 3/5\n\n**Example:** In a class of 12 boys and 8 girls:\n\n- Ratio of boys to girls = 12:8 = 3:2 (simplified)\n- Ratio of girls to total = 8:20 = 2:5\n\n## Simplifying Ratios\n\nDivide both numbers by their GCF (Greatest Common Factor)",
                        keyTerms: ["Ratio", "Comparison", "Simplify", "Equivalent"],
                        examples: [
                            {
                                problem: "Simplify the ratio 12:18",
                                solution: "2:3",
                                steps: ["1. Find GCF of 12 and 18 = 6", "2. Divide both by 6", "3. 12÷6 = 2, 18÷6 = 3", "4. Answer: 2:3"]
                            }
                        ],
                        practice: [
                            { text: "Simplify: 10:15", space: 50 },
                            { text: "Write ratio of vowels to consonants in 'MATHEMATICS'", space: 70 },
                            { text: "Juice mix is 2 cups concentrate to 5 cups water. Write as ratio.", space: 60 }
                        ]
                    }
                ]
            },
            "Probability": {
                title: "Introduction to Probability",
                curriculumCode: "6m4 - Data Management and Probability",
                overallExpectation: "determine and represent all the possible outcomes in a simple probability experiment",
                workbook: [
                    {
                        lessonNumber: 1,
                        lessonTitle: "Understanding Probability",
                        tutorial: "# Probability\n\n## What is Probability?\n\nThe chance that something will happen.\n\n## Probability Scale\n\n- **Impossible:** 0 (will never happen)\n- **Unlikely:** between 0 and 1/2\n- **Equally likely:** 1/2 (50-50 chance)\n- **Likely:** between 1/2 and 1\n- **Certain:** 1 (will definitely happen)\n\n## Formula\n\nProbability = Number of favorable outcomes / Total number of possible outcomes\n\n**Example:** Rolling a die\n\nP(rolling a 3) = 1/6\n\n- Favorable outcomes: 1 (only one 3)\n- Total outcomes: 6 (numbers 1-6)",
                        keyTerms: ["Probability", "Outcome", "Event", "Favorable", "Certain", "Impossible"],
                        examples: [
                            {
                                problem: "What's the probability of flipping heads on a coin?",
                                solution: "1/2 or 50%",
                                steps: ["1. Favorable outcomes: 1 (heads)", "2. Total outcomes: 2 (heads or tails)", "3. Probability = 1/2"]
                            }
                        ],
                        practice: [
                            { text: "Probability of rolling an even number on a die?", space: 70 },
                            { text: "Bag has 3 red, 2 blue, 5 green marbles. P(green)?", space: 70 },
                            { text: "Is it certain, likely, unlikely, or impossible to roll a 7 on a standard die?", space: 60 }
                        ]
                    }
                ]
            },
            "Coordinate Geometry": {
                title: "Introduction to the Coordinate Plane",
                curriculumCode: "6m4 - Geometry and Spatial Sense",
                overallExpectation: "plot points and describe patterns using the first quadrant of a coordinate system",
                workbook: [
                    {
                        lessonNumber: 1,
                        lessonTitle: "The Coordinate Plane",
                        tutorial: "# Coordinate Plane\n\n## Parts of the Coordinate Plane\n\n- **x-axis:** Horizontal line\n- **y-axis:** Vertical line\n- **Origin:** Where axes meet (0, 0)\n- **Coordinates:** (x, y) or ordered pair\n\n## Plotting Points\n\n1. Start at origin (0, 0)\n2. Move right/left along x-axis (first number)\n3. Move up/down along y-axis (second number)\n4. Mark the point\n\n**Example:** Point (3, 2)\n\n- Move 3 units right\n- Move 2 units up\n- Plot point",
                        keyTerms: ["Coordinate Plane", "x-axis", "y-axis", "Ordered Pair", "Origin"],
                        examples: [
                            {
                                problem: "What are the coordinates of a point 4 units right and 5 units up from the origin?",
                                solution: "(4, 5)",
                                steps: ["1. Right = x-coordinate = 4", "2. Up = y-coordinate = 5", "3. Write as ordered pair: (4, 5)"]
                            }
                        ],
                        practice: [
                            { text: "Plot these points: A(2,3), B(5,1), C(1,4)", space: 150 },
                            { text: "What are the coordinates of the origin?", space: 40 }
                        ]
                    }
                ]
            }
        },
        "Science": {
            "Space": {
                title: "Understanding the Solar System",
                curriculumCode: "6s3 - Earth and Space Systems",
                overallExpectation: "investigate characteristics of the systems of which the earth is a part",
                workbook: [
                    {
                        lessonNumber: 1,
                        lessonTitle: "The Solar System",
                        tutorial: "# The Solar System\n\n## What is the Solar System?\n\nThe Solar System consists of the Sun and everything that orbits around it.\n\n## The Sun\n\n- Star at the center\n- Provides heat and light\n- Made of hot gases (mostly hydrogen and helium)\n\n## The Planets\n\n**Inner Planets (Rocky):**\n- Mercury, Venus, Earth, Mars\n- Smaller and closer to Sun\n- Made of rock and metal\n\n**Outer Planets (Gas Giants):**\n- Jupiter, Saturn, Uranus, Neptune\n- Larger and farther from Sun\n- Made mostly of gas",
                        keyTerms: ["Solar System", "Planet", "Orbit", "Sun", "Star"],
                        examples: [
                            {
                                problem: "Which planets are inner planets?",
                                solution: "Mercury, Venus, Earth, and Mars",
                                steps: ["1. Inner planets are closest to Sun", "2. They are rocky planets", "3. Mercury, Venus, Earth, Mars"]
                            }
                        ],
                        practice: [
                            { text: "Name the four outer planets", space: 60 },
                            { text: "What is the main difference between inner and outer planets?", space: 80 },
                            { text: "Why is the Sun important to Earth?", space: 70 }
                        ]
                    }
                ]
            },
            "Biodiversity": {
                title: "Biodiversity and Living Systems",
                curriculumCode: "6s1 - Life Systems",
                overallExpectation: "assess human impacts on biodiversity, and identify ways of preserving biodiversity",
                workbook: [
                    {
                        lessonNumber: 1,
                        lessonTitle: "What is Biodiversity?",
                        tutorial: "# Biodiversity\n\n## Definition\n\nThe variety of all living things on Earth.\n\n## Three Types\n\n**1. Species Diversity**\n- Different types of organisms\n- More species = more biodiversity\n\n**2. Genetic Diversity**\n- Variety within species\n- Different traits and characteristics\n\n**3. Ecosystem Diversity**\n- Different habitats and ecosystems\n- Forests, oceans, deserts, wetlands\n\n## Why Biodiversity Matters\n\n- Keeps ecosystems healthy\n- Provides food, medicine, materials\n- Makes ecosystems more resilient\n- Helps with pollination\n\n## Threats to Biodiversity\n\n- Habitat destruction\n- Pollution\n- Climate change\n- Invasive species\n- Overharvesting",
                        keyTerms: ["Biodiversity", "Species", "Ecosystem", "Habitat", "Extinction"],
                        examples: [
                            {
                                problem: "Why is a rainforest more biodiverse than a desert?",
                                solution: "Rainforests have more resources (water, food) supporting many species",
                                steps: ["1. Rainforest has abundant water", "2. Many food sources available", "3. Can support more species"]
                            }
                        ],
                        practice: [
                            { text: "Give 3 reasons why biodiversity is important", space: 90 },
                            { text: "Name two threats to biodiversity", space: 60 },
                            { text: "How can humans protect biodiversity?", space: 80 }
                        ]
                    }
                ]
            }
        },
        "English": {
            "Reading Comprehension": {
                title: "Making Inferences and Drawing Conclusions",
                curriculumCode: "6e1 - Reading",
                overallExpectation: "read and demonstrate comprehension using inference skills",
                workbook: [
                    {
                        lessonNumber: 1,
                        lessonTitle: "Making Inferences",
                        tutorial: "# Making Inferences\n\n## What is an Inference?\n\nA conclusion based on evidence and reasoning.\n\n## Formula\n\nText Clues + My Knowledge = Inference\n\n## Steps to Infer\n\n1. **Read carefully**\n- What does the text say?\n\n2. **Look for clues**\n- Words, actions, descriptions\n\n3. **Use your brain**\n- What do you already know?\n\n4. **Put it together**\n- What can you conclude?\n\n## Example\n\nText: 'Maria shivered and pulled her coat tighter.'\n\nClues: shivering, pulling coat tight\nKnowledge: People do this when cold\nInference: It's cold outside",
                        keyTerms: ["Inference", "Evidence", "Conclusion", "Context Clues"],
                        examples: [
                            {
                                problem: "Text: 'Tom's stomach growled loudly during class.' What can you infer?",
                                solution: "Tom is hungry",
                                steps: ["1. Clue: stomach growled", "2. Knowledge: this happens when hungry", "3. Inference: Tom is hungry"]
                            }
                        ],
                        practice: [
                            { text: "What's the difference between inference and guessing?", space: 80 },
                            { text: "Infer: 'The house was dark. No cars in driveway. Mail overflowing.'", space: 90 },
                            { text: "Why do good readers make inferences?", space: 80 }
                        ]
                    }
                ]
            },
            "Text Features and Structures": {
                title: "Understanding Text Features and Organizational Structures",
                curriculumCode: "6e1 - Reading",
                overallExpectation: "identify text features and organizational structures in various texts",
                workbook: [
                    {
                        lessonNumber: 1,
                        lessonTitle: "Non-Fiction Text Features",
                        tutorial: "# Text Features\n\n## What are Text Features?\n\nSpecial parts of non-fiction texts that help readers find and understand information.\n\n## Common Text Features\n\n**1. Headings and Subheadings**\n- Tell what each section is about\n- Help you find information quickly\n\n**2. Bold and Italic Text**\n- **Bold** = important words or key terms\n- *Italic* = emphasis or titles\n\n**3. Captions**\n- Explain pictures, photos, or diagrams\n- Give extra information\n\n**4. Diagrams and Charts**\n- Show information visually\n- Compare data\n- Illustrate processes\n\n**5. Table of Contents**\n- Lists chapters/sections\n- Shows page numbers\n\n**6. Index**\n- Alphabetical list of topics\n- At back of book\n\n**7. Glossary**\n- Defines important words\n- Usually at end of book\n\n## Why Use Text Features?\n\n- Save time finding information\n- Understand content better\n- Preview what you'll read\n- Review key concepts",
                        keyTerms: ["Text Features", "Heading", "Caption", "Diagram", "Index", "Glossary"],
                        examples: [
                            {
                                problem: "You need to find information about polar bears in a science book. Which text feature would help you fastest?",
                                solution: "The index - it lists topics alphabetically with page numbers",
                                steps: ["1. Index is alphabetical", "2. Look up 'polar bears'", "3. Go to listed page number", "4. Fastest way to find specific topic"]
                            }
                        ],
                        practice: [
                            { text: "Name 3 text features you'd find in a science textbook", space: 70 },
                            { text: "Why are headings helpful when reading non-fiction?", space: 80 },
                            { text: "What's the difference between a table of contents and an index?", space: 90 }
                        ]
                    }
                ]
            },
            "Informative Writing": {
                title: "Writing to Inform and Explain",
                curriculumCode: "6e2 - Writing",
                overallExpectation: "write informative texts to explain and inform",
                workbook: [
                    {
                        lessonNumber: 1,
                        lessonTitle: "Writing Informative Paragraphs",
                        tutorial: "# Informative Writing\n\n## Purpose\n\nTo teach readers about a topic using facts and information.\n\n## Structure of Informative Paragraph\n\n**1. Topic Sentence**\n- States the main idea\n- First sentence\n- Example: 'Recycling helps protect our environment.'\n\n**2. Supporting Details**\n- Facts, examples, explanations\n- 3-5 sentences\n- Each supports the topic sentence\n\n**3. Concluding Sentence**\n- Wraps up the paragraph\n- Restates main idea in new words\n- Example: 'By recycling, we can make a real difference.'\n\n## Tips for Good Informative Writing\n\n**Use Facts, Not Opinions**\n- FACT: 'Canada has 10 provinces.'\n- OPINION: 'Canada is the best country.'\n\n**Be Clear and Specific**\n- WEAK: 'Many people live there.'\n- STRONG: 'Over 38 million people live in Canada.'\n\n**Organize Logically**\n- Time order (first, next, then, finally)\n- Order of importance (most to least)\n- Categories (types, groups)\n\n**Use Transition Words**\n- First, second, third\n- Also, in addition, furthermore\n- For example, such as\n- Therefore, as a result",
                        keyTerms: ["Informative Writing", "Topic Sentence", "Supporting Details", "Facts", "Transitions"],
                        examples: [
                            {
                                problem: "Write a topic sentence about butterflies",
                                solution: "Butterflies go through four stages of development in their life cycle.",
                                steps: ["1. Choose main idea (butterfly life cycle)", "2. Make it specific", "3. State it clearly", "4. This introduces what paragraph will explain"]
                            }
                        ],
                        practice: [
                            { text: "Write a topic sentence about your favorite sport", space: 60 },
                            { text: "List 3 facts about the solar system", space: 80 },
                            { text: "Write an informative paragraph about a Canadian animal (5-7 sentences)", space: 120 }
                        ]
                    }
                ]
            },
            "Grammar - Verb Tenses": {
                title: "Understanding and Using Verb Tenses",
                curriculumCode: "6e3 - Language Conventions",
                overallExpectation: "use verb tenses correctly in writing and speaking",
                workbook: [
                    {
                        lessonNumber: 1,
                        lessonTitle: "Past, Present, and Future Tenses",
                        tutorial: "# Verb Tenses\n\n## What is Tense?\n\nTense tells WHEN an action happens.\n\n## Three Main Tenses\n\n**1. PAST TENSE**\n- Action already happened\n- Usually add -ed\n- Examples:\n  - walk → walked\n  - play → played\n  - jump → jumped\n\n**2. PRESENT TENSE**\n- Action happening now\n- Or happens regularly\n- Examples:\n  - I walk to school (regular)\n  - She walks every day (add -s for he/she/it)\n  - They are walking (happening now)\n\n**3. FUTURE TENSE**\n- Action will happen later\n- Use 'will' or 'going to'\n- Examples:\n  - I will walk tomorrow\n  - She is going to walk later\n\n## Irregular Verbs\n\nDon't follow the -ed rule!\n\n| Present | Past | Future |\n|---------|------|--------|\n| go | went | will go |\n| eat | ate | will eat |\n| run | ran | will run |\n| see | saw | will see |\n| write | wrote | will write |\n\n## Staying Consistent\n\nDon't switch tenses in same story!\n\n**WRONG:** Yesterday I walk to the store and buy candy.\n**RIGHT:** Yesterday I walked to the store and bought candy.",
                        keyTerms: ["Verb Tense", "Past Tense", "Present Tense", "Future Tense", "Irregular Verbs"],
                        examples: [
                            {
                                problem: "Change to past tense: 'I play soccer every Saturday.'",
                                solution: "I played soccer every Saturday.",
                                steps: ["1. Find verb: play", "2. Change to past: played", "3. Keep rest of sentence same"]
                            }
                        ],
                        practice: [
                            { text: "Write the past tense: run, swim, eat, go, write", space: 70 },
                            { text: "Change to future: 'She reads a book.'", space: 60 },
                            { text: "Fix the tense errors: 'Yesterday I go to the park and play on the swings.'", space: 80 }
                        ]
                    }
                ]
            },
            "Compare and Contrast": {
                title: "Comparing and Contrasting Texts and Ideas",
                curriculumCode: "6e1 - Reading",
                overallExpectation: "compare and contrast information across texts",
                workbook: [
                    {
                        lessonNumber: 1,
                        lessonTitle: "Finding Similarities and Differences",
                        tutorial: "# Compare and Contrast\n\n## Definitions\n\n**Compare** = Find SIMILARITIES (how things are alike)\n**Contrast** = Find DIFFERENCES (how things are different)\n\n## Signal Words\n\n**Comparison Words (Alike):**\n- both, also, too\n- similarly, likewise\n- in the same way\n- as well as\n\n**Contrast Words (Different):**\n- but, however, although\n- on the other hand\n- while, whereas\n- in contrast, unlike\n\n## Venn Diagram\n\nGreat tool for comparing!\n\n```\n  Circle A    Overlap    Circle B\n  (Only A)    (Both)     (Only B)\n```\n\n## Writing Compare/Contrast\n\n**Method 1: Block Method**\n- Paragraph 1: All about Topic A\n- Paragraph 2: All about Topic B\n- Paragraph 3: Comparison\n\n**Method 2: Point-by-Point**\n- Paragraph 1: Feature 1 (A vs B)\n- Paragraph 2: Feature 2 (A vs B)\n- Paragraph 3: Feature 3 (A vs B)\n\n## Example\n\n**Topic:** Dogs vs. Cats\n\n**Similarities:**\n- Both are popular pets\n- Both need food and water\n- Both can be trained\n\n**Differences:**\n- Dogs need walks; cats use litter boxes\n- Dogs are more social; cats are independent\n- Dogs bark; cats meow",
                        keyTerms: ["Compare", "Contrast", "Similarities", "Differences", "Venn Diagram"],
                        examples: [
                            {
                                problem: "Compare books and movies. Give 1 similarity and 1 difference.",
                                solution: "Similarity: Both tell stories. Difference: Books use words; movies use visuals and sound.",
                                steps: ["1. Think about both", "2. Find what's same (both tell stories)", "3. Find what's different (format)", "4. State clearly"]
                            }
                        ],
                        practice: [
                            { text: "List 3 signal words for comparing and 3 for contrasting", space: 80 },
                            { text: "Compare and contrast summer and winter (2 similarities, 2 differences)", space: 100 },
                            { text: "Why is it useful to compare and contrast when reading?", space: 80 }
                        ]
                    }
                ]
            },
            "Media Literacy": {
                title: "Understanding Media Messages",
                curriculumCode: "6e1 - Media Literacy",
                overallExpectation: "identify and analyze media messages and techniques",
                workbook: [
                    {
                        lessonNumber: 1,
                        lessonTitle: "Analyzing Advertisements",
                        tutorial: "# Media Literacy\n\n## What is Media?\n\nWays information is shared:\n- TV, radio, internet\n- Newspapers, magazines\n- Social media, videos\n- Advertisements, posters\n\n## Purpose of Media\n\n**4 Main Purposes:**\n1. **Inform** - give facts/news\n2. **Entertain** - make you enjoy\n3. **Persuade** - convince you\n4. **Sell** - make you buy something\n\n## Advertising Techniques\n\n**1. Bandwagon**\n- 'Everyone's doing it!'\n- Makes you want to join in\n\n**2. Testimonial**\n- Famous person recommends it\n- 'If they use it, I should too!'\n\n**3. Emotional Appeal**\n- Makes you feel happy, sad, excited\n- Connects feelings to product\n\n**4. Repetition**\n- Shows/says same thing many times\n- Helps you remember\n\n**5. Exaggeration**\n- Makes claims seem bigger/better\n- 'Best ever!' 'Amazing!'\n\n## Questions to Ask\n\n**Who created this?**\n- What's their purpose?\n\n**Who is the audience?**\n- Who are they trying to reach?\n\n**What techniques are used?**\n- Colors, music, words?\n\n**What's the message?**\n- What do they want you to think/do?\n\n**What's missing?**\n- What don't they tell you?",
                        keyTerms: ["Media Literacy", "Advertisement", "Persuasion", "Audience", "Techniques"],
                        examples: [
                            {
                                problem: "A cereal ad shows kids having fun and says 'Join the fun! Everyone loves it!' What techniques are used?",
                                solution: "Bandwagon ('everyone loves it') and Emotional Appeal (showing fun/happiness)",
                                steps: ["1. Identify 'everyone' language = bandwagon", "2. Identify emotion shown = emotional appeal", "3. Both techniques work together"]
                            }
                        ],
                        practice: [
                            { text: "Name 3 advertising techniques and explain one", space: 90 },
                            { text: "Find an ad (magazine/online). What technique does it use?", space: 80 },
                            { text: "Why is it important to think critically about media messages?", space: 90 }
                        ]
                    }
                ]
            }
        }
    },
    "7": {
        "Mathematics": {
            "Integers": {
                title: "Operations with Integers",
                curriculumCode: "7m1 - Number Sense and Numeration",
                overallExpectation: "demonstrate an understanding of addition and subtraction of integers, and apply computational strategies to solve problems",
                workbook: [
                    {
                        lessonNumber: 1,
                        lessonTitle: "Understanding Integers",
                        tutorial: "# Understanding Integers\n\n## What are Integers?\n\nWhole numbers: positive, negative, or zero.\n\n**Number Line:**\n```\n    ←-------------------|-------------------→\n   -5  -4  -3  -2  -1   0   +1  +2  +3  +4  +5\n   NEGATIVE          ZERO          POSITIVE\n```\n\n## Real-World Examples\n\n- **Temperature:** -5°C (below freezing) or +25°C (warm)\n- **Money:** -$50 (debt/owe) or +$50 (have/earned)\n- **Elevation:** -10m (below sea level) or +100m (above sea level)",
                        keyTerms: ["Integer", "Positive", "Negative", "Zero", "Number Line"],
                        examples: [
                            {
                                problem: "Which is colder: -8°C or -3°C?",
                                solution: "-8°C is colder",
                                steps: ["1. Draw number line", "2. -8 is farther left than -3", "3. Farther left = smaller = colder", "4. Answer: -8°C"]
                            }
                        ],
                        practice: [
                            { text: "List 3 real-world situations using negative numbers", space: 90 },
                            { text: "Order from least to greatest: -3, +7, -9, 0, +2, -1", space: 50 }
                        ]
                    },
                    {
                        lessonNumber: 2,
                        lessonTitle: "Adding Integers",
                        tutorial: "# Adding Integers\n\n## Rule 1: Same Signs\n\n**Add the numbers, keep the sign**\n\n- (+3) + (+5) = +8\n- (-4) + (-6) = -10\n\n## Rule 2: Different Signs\n\n**Subtract smaller from larger, take sign of larger number**\n\n- (+7) + (-3) = +4\n- (-8) + (+2) = -6",
                        keyTerms: ["Addition", "Same Signs", "Different Signs"],
                        examples: [
                            {
                                problem: "(+9) + (-5)",
                                solution: "+4",
                                steps: ["1. Different signs", "2. Subtract: 9 - 5 = 4", "3. Larger number (+9) is positive", "4. Answer: +4"]
                            }
                        ],
                        practice: [
                            { text: "(+15) + (+23)", space: 50 },
                            { text: "(-18) + (-14)", space: 50 },
                            { text: "(+20) + (-7)", space: 50 }
                        ]
                    }
                ]
            },
            "Fractions and Percents": {
                title: "Fractions, Decimals, and Percents",
                curriculumCode: "7m1 - Number Sense and Numeration",
                overallExpectation: "demonstrate an understanding of proportional relationships using percent, ratio, and rate",
                workbook: [
                    {
                        lessonNumber: 1,
                        lessonTitle: "Converting Between Forms",
                        tutorial: "# Fractions, Decimals, Percents\n\n## Conversion Methods\n\n**Fraction → Decimal:**\nDivide numerator by denominator\n1/4 = 1 ÷ 4 = 0.25\n\n**Decimal → Percent:**\nMultiply by 100\n0.25 × 100 = 25%\n\n**Percent → Decimal:**\nDivide by 100\n75% = 75 ÷ 100 = 0.75\n\n**Percent → Fraction:**\nWrite over 100, simplify\n40% = 40/100 = 2/5",
                        keyTerms: ["Fraction", "Decimal", "Percent", "Conversion"],
                        examples: [
                            {
                                problem: "Convert 3/5 to a percent",
                                solution: "60%",
                                steps: ["1. Divide: 3 ÷ 5 = 0.6", "2. Multiply by 100: 0.6 × 100 = 60", "3. Add % sign: 60%"]
                            }
                        ],
                        practice: [
                            { text: "Convert 0.35 to a fraction and percent", space: 60 },
                            { text: "Convert 45% to a decimal and fraction", space: 60 }
                        ]
                    }
                ]
            },
            "Ratios and Rates": {
                title: "Ratios, Rates, and Proportions",
                curriculumCode: "7m1 - Number Sense and Numeration",
                overallExpectation: "solve problems involving percent, ratio, and rate",
                workbook: [
                    {
                        lessonNumber: 1,
                        lessonTitle: "Rates and Unit Rates",
                        tutorial: "# Rates\n\n## What is a Rate?\n\nA comparison of two quantities with **different units**.\n\n**Examples:**\n- 60 km/hour (distance per time)\n- $5/kg (price per mass)\n- 100 words/minute (words per time)\n\n## Unit Rate\n\nRate with denominator of 1.\n\n**Example:** $24 for 3 kg\n\nUnit rate = $24 ÷ 3 = $8/kg",
                        keyTerms: ["Rate", "Unit Rate", "Per", "Ratio"],
                        examples: [
                            {
                                problem: "A car travels 240 km in 4 hours. Find the unit rate.",
                                solution: "60 km/h",
                                steps: ["1. Divide distance by time", "2. 240 ÷ 4 = 60", "3. Answer: 60 km/h"]
                            }
                        ],
                        practice: [
                            { text: "$15 for 5 pencils. Find unit price.", space: 60 },
                            { text: "180 pages in 3 hours. Pages per hour?", space: 60 }
                        ]
                    }
                ]
            },
            "Algebra - Linear Relations": {
                title: "Patterning and Algebra",
                curriculumCode: "7m2 - Patterning and Algebra",
                overallExpectation: "model linear relationships using tables of values, graphs, and equations",
                workbook: [
                    {
                        lessonNumber: 1,
                        lessonTitle: "Linear Patterns",
                        tutorial: "# Linear Relations\n\n## What is Linear?\n\nA pattern with a **constant rate of change**.\n\nGraph is a straight line!\n\n**Example:** y = 2x + 1\n\n| x | y |\n|---|---|\n| 0 | 1 |\n| 1 | 3 |\n| 2 | 5 |\n| 3 | 7 |\n\nNotice: y increases by 2 each time (constant rate)",
                        keyTerms: ["Linear", "Variable", "Relation", "Table of Values"],
                        examples: [
                            {
                                problem: "Create table for y = 3x - 2 (x = 0,1,2,3)",
                                solution: "x: 0,1,2,3 | y: -2,1,4,7",
                                steps: ["1. x=0: y=3(0)-2=-2", "2. x=1: y=3(1)-2=1", "3. x=2: y=3(2)-2=4", "4. x=3: y=3(3)-2=7"]
                            }
                        ],
                        practice: [
                            { text: "Create table for y = 2x + 3 (x = 0,1,2,3,4)", space: 80 }
                        ]
                    }
                ]
            },
            "Data Management - Mean and Median": {
                title: "Central Tendency and Data Analysis",
                curriculumCode: "7m4 - Data Management and Probability",
                overallExpectation: "collect and organize data to solve problems and make informed decisions",
                workbook: [
                    {
                        lessonNumber: 1,
                        lessonTitle: "Mean, Median, and Mode",
                        tutorial: "# Measures of Central Tendency\n\n## Mean (Average)\n\nAdd all numbers, divide by how many numbers.\n\n**Example:** 5, 8, 10, 12\nMean = (5+8+10+12) ÷ 4 = 35 ÷ 4 = 8.75\n\n## Median (Middle)\n\n1. Put numbers in order\n2. Find middle number\n\n**Example:** 3, 5, 7, 9, 11\nMedian = 7\n\n## Mode (Most Common)\n\nNumber that appears most often.\n\n**Example:** 2, 3, 3, 5, 3, 8\nMode = 3",
                        keyTerms: ["Mean", "Median", "Mode", "Average", "Data"],
                        examples: [
                            {
                                problem: "Find mean of: 10, 15, 20, 25",
                                solution: "17.5",
                                steps: ["1. Add: 10+15+20+25 = 70", "2. Count numbers: 4", "3. Divide: 70 ÷ 4 = 17.5"]
                            }
                        ],
                        practice: [
                            { text: "Find mean, median, mode: 8, 12, 15, 12, 18", space: 80 }
                        ]
                    }
                ]
            }
        },
        "Science": {
            "Ecosystems": {
                title: "Interactions in Ecosystems",
                curriculumCode: "7s2 - Life Systems",
                overallExpectation: "demonstrate an understanding of an ecosystem as a system of interactions between living organisms and their environment",
                workbook: [
                    {
                        lessonNumber: 1,
                        lessonTitle: "Introduction to Ecosystems",
                        tutorial: "# Ecosystems\n\n## What is an Ecosystem?\n\nAll living things (biotic) and non-living things (abiotic) interacting in an environment.\n\n## Biotic Factors\n\n- **Living things**\n- Plants, animals, bacteria, fungi\n- Producers, consumers, decomposers\n\n## Abiotic Factors\n\n- **Non-living things**\n- Water, air, sunlight, soil, temperature\n- Rocks, minerals\n\n## Food Chains\n\n- Energy flows from Sun → Producers → Consumers\n- Producer: Makes own food (plants)\n- Consumer: Eats other organisms\n- Decomposer: Breaks down dead matter",
                        keyTerms: ["Ecosystem", "Biotic", "Abiotic", "Food Chain", "Producer", "Consumer"],
                        examples: [
                            {
                                problem: "Give 3 examples of abiotic factors in a forest",
                                solution: "Sunlight, water, air (or temperature, soil, rocks)",
                                steps: ["1. Abiotic = non-living", "2. Think about forest environment", "3. Examples: sunlight, water, air"]
                            }
                        ],
                        practice: [
                            { text: "List 5 biotic factors in an ecosystem", space: 70 },
                            { text: "Draw a simple food chain with 4 organisms", space: 100 },
                            { text: "Why are decomposers important?", space: 70 }
                        ]
                    }
                ]
            },
            "Heat Transfer": {
                title: "Heat in the Environment",
                curriculumCode: "7s4 - Energy and Matter",
                overallExpectation: "demonstrate an understanding of heat as a form of energy that is transferred and can be transformed",
                workbook: [
                    {
                        lessonNumber: 1,
                        lessonTitle: "Methods of Heat Transfer",
                        tutorial: "# Heat Transfer\n\n## Three Methods\n\n**1. Conduction**\n- Heat moves through direct contact\n- Example: Metal spoon gets hot in soup\n\n**2. Convection**\n- Heat moves through liquids and gases\n- Hot rises, cold sinks\n- Example: Boiling water circulates\n\n**3. Radiation**\n- Heat travels through space (no medium needed)\n- Example: Sun's heat reaches Earth\n\n## Temperature vs Heat\n\n- **Temperature:** How hot or cold something is\n- **Heat:** Energy moving from hot to cold",
                        keyTerms: ["Conduction", "Convection", "Radiation", "Heat", "Temperature"],
                        examples: [
                            {
                                problem: "What type of heat transfer warms your hands on a campfire?",
                                solution: "Radiation (heat travels through air without contact)",
                                steps: ["1. No direct contact with fire", "2. Heat travels through air", "3. This is radiation"]
                            }
                        ],
                        practice: [
                            { text: "Give an example of conduction in a kitchen", space: 70 },
                            { text: "Explain why hot air balloons rise", space: 80 },
                            { text: "How does a thermos keep drinks hot?", space: 80 }
                        ]
                    }
                ]
            }
        },
        "English": {
            "Reading Comprehension": {
                title: "Understanding Text and Author's Purpose",
                curriculumCode: "7e1 - Reading",
                overallExpectation: "read and demonstrate an understanding of a variety of literary, graphic, and informational texts",
                workbook: [
                    {
                        lessonNumber: 1,
                        lessonTitle: "Author's Purpose",
                        tutorial: "# Author's Purpose\n\n## Why do authors write?\n\nEvery text has a PURPOSE - a reason the author wrote it.\n\n## The 3 Main Purposes\n\n**1. To PERSUADE**\n- Convince you to agree\n- Advertisements, opinion articles\n- Uses: strong words, opinions, appeals to emotion\n\n**2. To INFORM**\n- Teach you facts\n- Textbooks, news articles, instructions\n- Uses: facts, definitions, examples\n\n**3. To ENTERTAIN**\n- Make you enjoy reading\n- Stories, poems, jokes\n- Uses: description, dialogue, plot\n\n## How to Identify\n\nAsk: What does the author want me to do/think/feel?",
                        keyTerms: ["Author's Purpose", "Persuade", "Inform", "Entertain"],
                        examples: [
                            {
                                problem: "What is the author's purpose in a recipe?",
                                solution: "To inform (teach how to make food)",
                                steps: ["1. Think about what the text does", "2. Recipe gives instructions and facts", "3. Purpose is to inform"]
                            }
                        ],
                        practice: [
                            { text: "What is the author's purpose in a comic book?", space: 60 },
                            { text: "What is the author's purpose in a 'Save the Forests' poster?", space: 70 },
                            { text: "Write one sentence with purpose to persuade", space: 80 }
                        ]
                    }
                ]
            }
        },
        "Social Studies": {
            "New France": {
                title: "Early Canadian History - New France",
                curriculumCode: "7h1 - Heritage and Identity",
                overallExpectation: "describe the major challenges facing individuals, groups, and/or organizations in New France",
                workbook: [
                    {
                        lessonNumber: 1,
                        lessonTitle: "The Fur Trade",
                        tutorial: "# The Fur Trade\n\n## What was the Fur Trade?\n\nThe exchange of furs (especially beaver pelts) for European goods.\n\n## Key Groups\n\n**1. Indigenous Peoples**\n- Trapped and prepared furs\n- Expert traders and guides\n- Had knowledge of land\n\n**2. French Traders (Coureurs de bois)**\n- Traveled into wilderness\n- Built relationships with Indigenous peoples\n- Brought furs to trading posts\n\n**3. Trading Companies**\n- Bought furs from traders\n- Sold furs in Europe for profit\n- Example: Hudson's Bay Company\n\n## Why Beaver Pelts?\n\n- Popular in Europe for hats\n- Waterproof fur\n- High demand = high prices",
                        keyTerms: ["Fur Trade", "Beaver Pelt", "Coureurs de bois", "Indigenous Peoples", "Trading Post"],
                        examples: [
                            {
                                problem: "Why were Indigenous peoples essential to the fur trade?",
                                solution: "They had expertise in trapping, knew the land, and supplied the furs",
                                steps: ["1. Consider what Europeans didn't know", "2. Indigenous peoples had skills and knowledge", "3. They were essential partners"]
                            }
                        ],
                        practice: [
                            { text: "List 3 items Europeans might trade for furs", space: 70 },
                            { text: "Why was beaver fur valuable in Europe?", space: 70 },
                            { text: "Describe the role of coureurs de bois", space: 80 }
                        ]
                    }
                ]
            }
        }
    },
    "8": {
        "Mathematics": {
            "Percent and Rate": {
                title: "Percents, Ratios, and Rates",
                curriculumCode: "8m1 - Number Sense and Numeration",
                overallExpectation: "solve problems involving percents, ratios, and rates",
                workbook: [
                    {
                        lessonNumber: 1,
                        lessonTitle: "Calculating Percent of a Number",
                        tutorial: "# Working with Percents\n\n## Finding Percent of a Number\n\n**Method:** Convert to decimal, then multiply\n\n**Example:** What is 25% of 80?\n\n1. Convert: 25% = 0.25\n2. Multiply: 0.25 × 80 = 20\n\n## Percent Increase/Decrease\n\n**Sale:** Original $40, 20% off\n\n1. Find discount: 40 × 0.20 = $8\n2. Subtract: $40 - $8 = $32",
                        keyTerms: ["Percent", "Discount", "Increase", "Decrease"],
                        examples: [
                            {
                                problem: "What is 15% of 60?",
                                solution: "9",
                                steps: ["1. Convert: 15% = 0.15", "2. Multiply: 0.15 × 60 = 9"]
                            }
                        ],
                        practice: [
                            { text: "Find 20% of 150", space: 50 },
                            { text: "A $80 jacket is 25% off. Sale price?", space: 70 }
                        ]
                    }
                ]
            },
            "Linear Equations": {
                title: "Solving Linear Equations",
                curriculumCode: "8m2 - Patterning and Algebra",
                overallExpectation: "model and solve linear equations",
                workbook: [
                    {
                        lessonNumber: 1,
                        lessonTitle: "One-Step Equations",
                        tutorial: "# Solving Equations\n\n## Goal\n\nIsolate the variable (get x alone)\n\n## One-Step Equations\n\n**Addition:** x + 5 = 12\nSubtract 5: x = 7\n\n**Subtraction:** x - 3 = 10\nAdd 3: x = 13\n\n**Multiplication:** 3x = 15\nDivide by 3: x = 5\n\n**Division:** x/4 = 2\nMultiply by 4: x = 8",
                        keyTerms: ["Equation", "Variable", "Solution", "Isolate"],
                        examples: [
                            {
                                problem: "Solve: x + 7 = 15",
                                solution: "x = 8",
                                steps: ["1. Subtract 7 from both sides", "2. x = 15 - 7", "3. x = 8"]
                            }
                        ],
                        practice: [
                            { text: "Solve: x - 5 = 12", space: 60 },
                            { text: "Solve: 4x = 28", space: 60 }
                        ]
                    },
                    {
                        lessonNumber: 2,
                        lessonTitle: "Two-Step Equations",
                        tutorial: "# Two-Step Equations\n\n## Steps\n\n1. Undo addition/subtraction first\n2. Then undo multiplication/division\n\n**Example:** 3x + 5 = 20\n\n1. Subtract 5: 3x = 15\n2. Divide by 3: x = 5\n\n## Check Your Answer\n\nSubstitute back:\n3(5) + 5 = 15 + 5 = 20 ✓",
                        keyTerms: ["Two-Step", "Inverse Operations"],
                        examples: [
                            {
                                problem: "Solve: 2x - 7 = 11",
                                solution: "x = 9",
                                steps: ["1. Add 7: 2x = 18", "2. Divide by 2: x = 9", "3. Check: 2(9)-7 = 18-7 = 11 ✓"]
                            }
                        ],
                        practice: [
                            { text: "Solve: 4x + 3 = 27", space: 70 },
                            { text: "Solve: 5x - 10 = 2x + 8", space: 80 }
                        ]
                    }
                ]
            },
            "Pythagorean Theorem": {
                title: "The Pythagorean Theorem",
                curriculumCode: "8m4 - Geometry and Spatial Sense",
                overallExpectation: "use the Pythagorean theorem to solve problems",
                workbook: [
                    {
                        lessonNumber: 1,
                        lessonTitle: "Understanding the Pythagorean Theorem",
                        tutorial: "# Pythagorean Theorem\n\n## The Formula\n\na² + b² = c²\n\n## Parts of Right Triangle\n\n- **a, b:** Legs (sides forming right angle)\n- **c:** Hypotenuse (longest side, opposite right angle)\n\n## When to Use\n\nONLY for RIGHT TRIANGLES (one 90° angle)\n\n**Example:** Find c if a = 3, b = 4\n\n1. 3² + 4² = c²\n2. 9 + 16 = c²\n3. 25 = c²\n4. c = 5",
                        keyTerms: ["Pythagorean Theorem", "Right Triangle", "Hypotenuse", "Legs"],
                        examples: [
                            {
                                problem: "Find c if a = 6, b = 8",
                                solution: "c = 10",
                                steps: ["1. a² + b² = c²", "2. 6² + 8² = c²", "3. 36 + 64 = c²", "4. 100 = c²", "5. c = 10"]
                            }
                        ],
                        practice: [
                            { text: "Find c if a = 5 and b = 12", space: 80 },
                            { text: "Ladder is 13m long, base 5m from wall. How high does it reach?", space: 90 }
                        ]
                    }
                ]
            },
            "Surface Area and Volume": {
                title: "3D Measurement",
                curriculumCode: "8m3 - Measurement",
                overallExpectation: "determine the surface area and volume of prisms, pyramids, and cylinders",
                workbook: [
                    {
                        lessonNumber: 1,
                        lessonTitle: "Surface Area of Rectangular Prisms",
                        tutorial: "# Surface Area\n\n## What is Surface Area?\n\nTotal area of ALL faces of a 3D shape.\n\nMeasured in square units (cm², m²)\n\n## Rectangular Prism Formula\n\nSA = 2(lw + lh + wh)\n\nWhere:\n- l = length\n- w = width\n- h = height\n\n**Example:** l=4, w=3, h=2\n\nSA = 2(4×3 + 4×2 + 3×2)\nSA = 2(12 + 8 + 6)\nSA = 2(26) = 52 cm²",
                        keyTerms: ["Surface Area", "Prism", "Face", "3D"],
                        examples: [
                            {
                                problem: "Find SA: length=5cm, width=4cm, height=3cm",
                                solution: "94 cm²",
                                steps: ["1. Use formula: SA = 2(lw + lh + wh)", "2. SA = 2(5×4 + 5×3 + 4×3)", "3. SA = 2(20 + 15 + 12)", "4. SA = 2(47) = 94 cm²"]
                            }
                        ],
                        practice: [
                            { text: "Find surface area: 6cm × 4cm × 2cm prism", space: 80 }
                        ]
                    },
                    {
                        lessonNumber: 2,
                        lessonTitle: "Volume of Rectangular Prisms",
                        tutorial: "# Volume\n\n## What is Volume?\n\nAmount of space INSIDE a 3D shape.\n\nMeasured in cubic units (cm³, m³)\n\n## Formula\n\nVolume = length × width × height\n\nV = l × w × h\n\n**Example:** l=4cm, w=3cm, h=2cm\n\nV = 4 × 3 × 2 = 24 cm³",
                        keyTerms: ["Volume", "Cubic Units", "Capacity"],
                        examples: [
                            {
                                problem: "Find volume: 5cm × 4cm × 3cm",
                                solution: "60 cm³",
                                steps: ["1. V = l × w × h", "2. V = 5 × 4 × 3", "3. V = 60 cm³"]
                            }
                        ],
                        practice: [
                            { text: "Find volume: 8m × 5m × 3m", space: 60 },
                            { text: "Which holds more: 6×4×3 box or 5×5×5 box?", space: 80 }
                        ]
                    }
                ]
            }
        },
        "Science": {
            "Cells": {
                title: "Cell Structure and Function",
                curriculumCode: "8s1 - Life Systems",
                overallExpectation: "demonstrate an understanding of the basic structure and function of plant and animal cells",
                workbook: [
                    {
                        lessonNumber: 1,
                        lessonTitle: "Introduction to Cells",
                        tutorial: "# Cells - The Building Blocks of Life\n\n## What is a Cell?\n\nThe smallest unit of life. All living things are made of cells!\n\n## Cell Theory\n\n1. All living things are made of cells\n2. Cells are the basic unit of life\n3. All cells come from other cells\n\n## Types of Cells\n\n**Plant Cells:**\n- Have cell wall (rigid structure)\n- Have chloroplasts (make food)\n- Rectangular shape\n\n**Animal Cells:**\n- No cell wall (flexible)\n- No chloroplasts\n- Round or irregular shape\n\n## Common Parts (Both Have)\n\n- **Cell membrane:** Controls what enters/exits\n- **Cytoplasm:** Jelly-like substance inside\n- **Nucleus:** Control center (brain of cell)\n- **Mitochondria:** Power plant (makes energy)",
                        keyTerms: ["Cell", "Cell Membrane", "Nucleus", "Cytoplasm", "Chloroplast", "Cell Wall"],
                        examples: [
                            {
                                problem: "What is one difference between plant and animal cells?",
                                solution: "Plant cells have a cell wall and chloroplasts; animal cells don't",
                                steps: ["1. Think about plant cells", "2. Think about animal cells", "3. Identify unique structures"]
                            }
                        ],
                        practice: [
                            { text: "Draw and label a plant cell with 5 parts", space: 150 },
                            { text: "What is the function of the nucleus?", space: 60 },
                            { text: "Why do plant cells need chloroplasts?", space: 70 }
                        ]
                    }
                ]
            },
            "Light and Optics": {
                title: "Light Energy and Optical Systems",
                curriculumCode: "8s3 - Energy and Matter",
                overallExpectation: "demonstrate an understanding of light as a form of energy and its properties",
                workbook: [
                    {
                        lessonNumber: 1,
                        lessonTitle: "How Light Behaves",
                        tutorial: "# Properties of Light\n\n## Light Travels in Straight Lines\n\n- Light rays move in straight paths\n- Creates shadows when blocked\n\n## Three Things Light Can Do\n\n**1. Reflection**\n- Light bounces off surfaces\n- Mirrors reflect light\n- Law: Angle in = Angle out\n\n**2. Refraction**\n- Light bends when entering different materials\n- Makes straws look bent in water\n- Used in lenses\n\n**3. Absorption**\n- Material takes in light\n- Dark colors absorb more\n- Converted to heat energy\n\n## Transparent, Translucent, Opaque\n\n- **Transparent:** See through clearly (glass)\n- **Translucent:** Some light passes (frosted glass)\n- **Opaque:** No light passes (wood, metal)",
                        keyTerms: ["Reflection", "Refraction", "Absorption", "Transparent", "Opaque"],
                        examples: [
                            {
                                problem: "Why does a pencil look bent in a glass of water?",
                                solution: "Refraction - light bends when moving from water to air",
                                steps: ["1. Light travels from water to air", "2. Speed changes cause bending", "3. This is refraction"]
                            }
                        ],
                        practice: [
                            { text: "Give 2 examples of transparent materials", space: 60 },
                            { text: "Draw how light reflects off a mirror", space: 100 },
                            { text: "Why do we see colors?", space: 70 }
                        ]
                    }
                ]
            },
            "Water Systems": {
                title: "Water Systems on Earth",
                curriculumCode: "8s2 - Earth and Space Systems",
                overallExpectation: "demonstrate an understanding of the water systems on Earth",
                workbook: [
                    {
                        lessonNumber: 1,
                        lessonTitle: "The Water Cycle",
                        tutorial: "# The Water Cycle\n\n## What is the Water Cycle?\n\nContinuous movement of water on, above, and below Earth's surface.\n\n## The Four Main Processes\n\n**1. Evaporation**\n- Sun heats water\n- Liquid → gas (water vapor)\n- From oceans, lakes, rivers\n\n**2. Condensation**\n- Water vapor cools\n- Gas → liquid\n- Forms clouds\n\n**3. Precipitation**\n- Water falls from clouds\n- Rain, snow, sleet, hail\n\n**4. Collection**\n- Water gathers in oceans, lakes, rivers\n- Soaks into ground (groundwater)\n- Cycle repeats\n\n## Why It's Important\n\n- Provides fresh water\n- Distributes heat around Earth\n- Same water has been recycling for billions of years!",
                        keyTerms: ["Water Cycle", "Evaporation", "Condensation", "Precipitation", "Groundwater"],
                        examples: [
                            {
                                problem: "What happens to puddles after rain on a sunny day?",
                                solution: "Evaporation - sun heats water which becomes water vapor",
                                steps: ["1. Sun provides heat energy", "2. Liquid water becomes gas", "3. This is evaporation"]
                            }
                        ],
                        practice: [
                            { text: "Draw and label the water cycle", space: 150 },
                            { text: "What role does the sun play in the water cycle?", space: 70 },
                            { text: "How does water get into clouds?", space: 70 }
                        ]
                    }
                ]
            }
        },
        "English": {
            "Literary Devices": {
                title: "Understanding Literary Devices",
                curriculumCode: "8e1 - Reading",
                overallExpectation: "identify and explain literary devices used in texts",
                workbook: [
                    {
                        lessonNumber: 1,
                        lessonTitle: "Common Literary Devices",
                        tutorial: "# Literary Devices\n\n## What are Literary Devices?\n\nTechniques authors use to make writing more interesting and meaningful.\n\n## Common Devices\n\n**Simile:**\n- Comparison using 'like' or 'as'\n- Example: \"Fast as lightning\"\n\n**Metaphor:**\n- Direct comparison (says something IS something else)\n- Example: \"Time is money\"\n\n**Personification:**\n- Giving human qualities to non-human things\n- Example: \"The wind whispered\"\n\n**Alliteration:**\n- Repeating same sound at start of words\n- Example: \"Peter Piper picked\"\n\n**Hyperbole:**\n- Extreme exaggeration\n- Example: \"I'm so hungry I could eat a horse\"\n\n**Imagery:**\n- Descriptive language that creates mental pictures\n- Appeals to 5 senses",
                        keyTerms: ["Simile", "Metaphor", "Personification", "Alliteration", "Hyperbole", "Imagery"],
                        examples: [
                            {
                                problem: "Identify the device: 'The classroom was a zoo'",
                                solution: "Metaphor (direct comparison without 'like' or 'as')",
                                steps: ["1. Is it a comparison? Yes", "2. Does it use 'like' or 'as'? No", "3. It's a metaphor"]
                            }
                        ],
                        practice: [
                            { text: "Write a simile about speed", space: 60 },
                            { text: "Give example of personification with weather", space: 70 },
                            { text: "Why do authors use literary devices?", space: 80 }
                        ]
                    }
                ]
            },
            "Writing": {
                title: "Persuasive Writing Techniques",
                curriculumCode: "8e2 - Writing",
                overallExpectation: "write persuasive texts to convince an audience",
                workbook: [
                    {
                        lessonNumber: 1,
                        lessonTitle: "Elements of Persuasion",
                        tutorial: "# Persuasive Writing\n\n## Goal\n\nConvince your reader to agree with your opinion or take action.\n\n## Persuasive Techniques\n\n**1. Facts and Statistics**\n- Use real data to support claims\n- Example: \"90% of students prefer...\"\n\n**2. Expert Opinions**\n- Quote specialists or authorities\n- Adds credibility\n\n**3. Emotional Appeal**\n- Connect to readers' feelings\n- Example: \"Imagine a world without...\"\n\n**4. Logical Reasoning**\n- Use cause and effect\n- Show clear connections\n\n**5. Call to Action**\n- Tell reader what to do\n- Example: \"Join us today!\"\n\n## Structure\n\n1. Introduction (state your position)\n2. Body (give reasons and evidence)\n3. Conclusion (restate and call to action)",
                        keyTerms: ["Persuasive", "Opinion", "Evidence", "Call to Action", "Emotional Appeal"],
                        examples: [
                            {
                                problem: "Which is more persuasive: 'Recycling is good' or 'Recycling reduces waste by 70%'?",
                                solution: "The second - it uses specific facts/statistics",
                                steps: ["1. First is just opinion", "2. Second has data", "3. Facts are more convincing"]
                            }
                        ],
                        practice: [
                            { text: "Write a persuasive sentence about school uniforms", space: 80 },
                            { text: "What emotion might an animal shelter ad appeal to?", space: 70 },
                            { text: "Give a call to action for recycling", space: 60 }
                        ]
                    }
                ]
            }
        },
        "Social Studies": {
            "Confederation": {
                title: "Canadian Confederation",
                curriculumCode: "8h1 - Heritage and Identity",
                overallExpectation: "explain the social, political, and economic changes that occurred in Canada between 1850 and 1890",
                workbook: [
                    {
                        lessonNumber: 1,
                        lessonTitle: "Why Canada United in 1867",
                        tutorial: "# Confederation\n\n## What was Confederation?\n\nJuly 1, 1867: Four colonies united to form the Dominion of Canada.\n\n## The Original Four Provinces\n\n1. Ontario (Canada West)\n2. Quebec (Canada East)\n3. Nova Scotia\n4. New Brunswick\n\n## Reasons for Confederation\n\n**1. Political Deadlock**\n- Canada West and Canada East couldn't agree\n- Government couldn't make decisions\n\n**2. Economic Benefits**\n- Larger market for trade\n- Build railways together\n- Stronger economy\n\n**3. Defense**\n- Threat from United States\n- Stronger together against attack\n\n**4. Railway Dreams**\n- Needed transcontinental railway\n- Too expensive for colonies alone\n\n## The Fathers of Confederation\n\n- John A. Macdonald (first Prime Minister)\n- George-Étienne Cartier\n- George Brown\n- And others who negotiated union",
                        keyTerms: ["Confederation", "Dominion", "Colony", "Political Deadlock", "John A. Macdonald"],
                        examples: [
                            {
                                problem: "Why was defense a reason for Confederation?",
                                solution: "The colonies feared American expansion and felt safer united",
                                steps: ["1. Small colonies were vulnerable", "2. USA was powerful neighbor", "3. United = stronger defense"]
                            }
                        ],
                        practice: [
                            { text: "Name the four original provinces of Canada", space: 70 },
                            { text: "Explain one economic reason for Confederation", space: 80 },
                            { text: "Who was Canada's first Prime Minister?", space: 50 }
                        ]
                    }
                ]
            },
            "Canadian Pacific Railway": {
                title: "Building the Canadian Pacific Railway",
                curriculumCode: "8h1 - Heritage and Identity",
                overallExpectation: "describe some of the effects of key policies and practices related to immigration in Canada",
                workbook: [
                    {
                        lessonNumber: 1,
                        lessonTitle: "The CPR: Connecting Canada",
                        tutorial: "# The Canadian Pacific Railway (CPR)\n\n## Why Build the Railway?\n\n**1. Unite Canada**\n- Connect provinces coast to coast\n- British Columbia joined Canada on promise of railway\n\n**2. Settle the West**\n- Bring settlers to prairies\n- Develop agriculture\n\n**3. Economic Growth**\n- Move goods and resources\n- Trade across country\n\n## Building Challenges\n\n- Rocky Mountains were difficult terrain\n- Expensive (cost millions)\n- Harsh weather conditions\n- Dangerous work\n\n## Chinese Workers\n\n- Thousands of Chinese laborers hired\n- Did most dangerous work (dynamite, tunnels)\n- Paid less than other workers\n- Faced discrimination\n- Many died building railway\n\n## Completion\n\n- Finished November 7, 1885\n- Last spike driven at Craigellachie, BC\n- Dream of transcontinental railway achieved",
                        keyTerms: ["Canadian Pacific Railway", "Transcontinental", "British Columbia", "Chinese Workers", "Last Spike"],
                        examples: [
                            {
                                problem: "Why was BC's agreement to join Canada dependent on the railway?",
                                solution: "BC needed transportation link to rest of Canada for trade and connection",
                                steps: ["1. BC was isolated on west coast", "2. No easy way to connect to eastern Canada", "3. Railway was essential"]
                            }
                        ],
                        practice: [
                            { text: "List 3 reasons why the CPR was important", space: 90 },
                            { text: "Describe challenges faced building through the Rockies", space: 80 },
                            { text: "What contributions did Chinese workers make?", space: 80 }
                        ]
                    }
                ]
            }
        }
    }
};
