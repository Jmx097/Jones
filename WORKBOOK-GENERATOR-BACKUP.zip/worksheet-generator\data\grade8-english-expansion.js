// Additional Grade 8 English Topics
// To be integrated into main curriculum.js

const grade8EnglishExpansion = {
    "Argumentative Writing": {
        title: "Crafting Strong Arguments and Debates",
        curriculumCode: "8e2 - Writing",
        overallExpectation: "write argumentative texts with well-supported claims",
        workbook: [
            {
                lessonNumber: 1,
                lessonTitle: "Building a Strong Argument",
                tutorial: "# Argumentative Writing\n\n## Argument vs. Persuasion\n\n**Persuasive:** Appeals to emotions, opinions\n**Argumentative:** Based on logic, facts, evidence\n\n## Structure of Argumentative Essay\n\n**1. INTRODUCTION**\n- Hook (grab attention)\n- Background information\n- Thesis statement (your claim)\n\n**2. BODY PARAGRAPHS** (3-5)\n- Topic sentence (one reason)\n- Evidence (facts, statistics, expert quotes)\n- Explanation (how evidence supports claim)\n- Transition to next paragraph\n\n**3. COUNTERARGUMENT PARAGRAPH**\n- Acknowledge opposing view\n- Present their strongest point\n- Refute with evidence\n- Strengthen your position\n\n**4. CONCLUSION**\n- Restate thesis (different words)\n- Summarize main points\n- Call to action or final thought\n\n## Types of Evidence\n\n**FACTS:** Proven information\n- Example: 'Canada has 10 provinces'\n\n**STATISTICS:** Numerical data\n- Example: '75% of students prefer...'\n\n**EXPERT OPINIONS:** Quotes from authorities\n- Example: 'Dr. Smith states that...'\n\n**EXAMPLES:** Specific instances\n- Example: 'In Finland, schools start at 9am and...'\n\n**LOGICAL REASONING:** If-then statements\n- Example: 'If students sleep more, then grades improve'\n\n## Transition Words for Arguments\n\n**Adding:** Furthermore, moreover, additionally\n**Contrasting:** However, nevertheless, on the other hand\n**Cause/Effect:** Therefore, consequently, as a result\n**Emphasis:** Indeed, in fact, certainly",
                keyTerms: ["Argumentative Writing", "Claim", "Evidence", "Counterargument", "Refutation", "Thesis"],
                examples: [
                    {
                        problem: "Write a thesis statement about whether cell phones should be allowed in schools",
                        solution: "Cell phones should be allowed in schools because they enhance learning, improve safety, and teach digital responsibility.",
                        steps: ["1. State clear position (should be allowed)", "2. Give 3 reasons", "3. Make it specific and debatable", "4. Use 'because' to connect reasons"]
                    }
                ],
                practice: [
                    { text: "Write a counterargument to: 'Homework is necessary for learning'", space: 90 },
                    { text: "Give 3 types of evidence you could use to argue for more recess time", space: 100 },
                    { text: "Write a thesis statement about school uniforms (include 2-3 reasons)", space: 90 }
                ]
            }
        ]
    },
    "Critical Analysis": {
        title: "Analyzing Texts Critically",
        curriculumCode: "8e1 - Reading",
        overallExpectation: "analyze texts critically for bias, perspective, and deeper meaning",
        workbook: [
            {
                lessonNumber: 1,
                lessonTitle: "Identifying Bias and Perspective",
                tutorial: "# Critical Analysis\n\n## What is Critical Reading?\n\nReading actively to question, evaluate, and analyze - not just accept.\n\n## Identifying Bias\n\n**What is Bias?**\n- Prejudice for or against something\n- One-sided view\n- Unfair preference\n\n**Types of Bias:**\n\n**1. Word Choice Bias**\n- Loaded language\n- Example: 'freedom fighter' vs. 'rebel'\n\n**2. Selection Bias**\n- Choosing only certain facts\n- Leaving out opposing information\n\n**3. Source Bias**\n- Only quoting one side\n- Ignoring other perspectives\n\n**4. Visual Bias**\n- Unflattering photos\n- Selective images\n\n## Analyzing Perspective\n\n**Questions to Ask:**\n- Who wrote this?\n- What is their background?\n- What is their purpose?\n- Who benefits from this view?\n- What perspectives are missing?\n\n## Point of View\n\n**First Person:** I, me, we (narrator is character)\n**Second Person:** You (addresses reader)\n**Third Person Limited:** He, she, they (one character's thoughts)\n**Third Person Omniscient:** All characters' thoughts\n\n## Fact vs. Opinion\n\n**FACT:** Can be proven true/false\n- Example: 'Toronto is in Ontario'\n\n**OPINION:** Personal belief/judgment\n- Example: 'Toronto is the best city'\n\n**Opinion Signal Words:**\n- I think, I believe, in my opinion\n- Should, ought to, must\n- Best, worst, most, least\n- Always, never (absolutes)",
                keyTerms: ["Bias", "Perspective", "Point of View", "Fact", "Opinion", "Critical Reading"],
                examples: [
                    {
                        problem: "Identify bias: 'The reckless protesters disrupted traffic'",
                        solution: "Word choice bias - 'reckless' and 'disrupted' are negative, loaded words",
                        steps: ["1. Identify loaded words (reckless, disrupted)", "2. Consider neutral alternatives (protesters blocked traffic)", "3. Recognize negative bias"]
                    }
                ],
                practice: [
                    { text: "Rewrite with opposite bias: 'The brave activists stood up for their rights'", space: 80 },
                    { text: "List 3 questions to ask when checking for bias in an article", space: 90 },
                    { text: "Is this fact or opinion? 'Students should have less homework.' Explain.", space: 70 }
                ]
            }
        ]
    },
    "Advanced Grammar": {
        title: "Mastering Advanced Grammar Concepts",
        curriculumCode: "8e3 - Language Conventions",
        overallExpectation: "use advanced grammar structures correctly and effectively",
        workbook: [
            {
                lessonNumber: 1,
                lessonTitle: "Active vs. Passive Voice",
                tutorial: "# Active and Passive Voice\n\n## Active Voice\n\n**Structure:** Subject + Verb + Object\n**Example:** The dog (subject) chased (verb) the cat (object)\n\n**Characteristics:**\n- Subject performs action\n- Direct and clear\n- Stronger writing\n- Preferred in most writing\n\n## Passive Voice\n\n**Structure:** Object + be verb + past participle + by + subject\n**Example:** The cat (object) was chased (verb) by the dog (subject)\n\n**Characteristics:**\n- Subject receives action\n- Less direct\n- Use when:\n  - Actor unknown: 'The window was broken'\n  - Actor unimportant: 'The law was passed in 1982'\n  - Want to emphasize object: 'The Mona Lisa was painted by da Vinci'\n\n## How to Identify\n\n**Active:** Subject does the action\n- 'Sarah wrote the essay'\n\n**Passive:** Subject receives the action\n- 'The essay was written by Sarah'\n\n## Converting Between Voices\n\n**Active → Passive:**\n1. Move object to front\n2. Add 'be' verb\n3. Change main verb to past participle\n4. Add 'by' + original subject\n\n**Example:**\n- Active: 'The teacher graded the tests'\n- Passive: 'The tests were graded by the teacher'\n\n**Passive → Active:**\n1. Identify who/what after 'by'\n2. Make that the subject\n3. Remove 'be' verb\n4. Change verb to active form\n\n## When to Use Each\n\n**Use Active When:**\n- Writing narratives\n- Want strong, clear sentences\n- Emphasizing the doer\n\n**Use Passive When:**\n- Doer is unknown\n- Doer is obvious\n- Want to emphasize action/object\n- Scientific writing",
                keyTerms: ["Active Voice", "Passive Voice", "Subject", "Object", "Past Participle"],
                examples: [
                    {
                        problem: "Convert to passive: 'The chef prepared the meal'",
                        solution: "The meal was prepared by the chef",
                        steps: ["1. Object becomes subject (the meal)", "2. Add 'was'", "3. Change verb to past participle (prepared)", "4. Add 'by the chef'"]
                    }
                ],
                practice: [
                    { text: "Identify voice: 'The book was read by millions of people'", space: 50 },
                    { text: "Convert to active: 'The game was won by our team'", space: 60 },
                    { text: "Convert to passive: 'Shakespeare wrote Romeo and Juliet'", space: 70 },
                    { text: "Why is active voice usually preferred in writing?", space: 80 }
                ]
            }
        ]
    },
    "Media Analysis": {
        title: "Analyzing Media Messages and Techniques",
        curriculumCode: "8e1 - Media Literacy",
        overallExpectation: "analyze media texts for techniques, messages, and impact",
        workbook: [
            {
                lessonNumber: 1,
                lessonTitle: "Deconstructing Media Messages",
                tutorial: "# Media Analysis\n\n## Key Concepts in Media Literacy\n\n**1. ALL MEDIA ARE CONSTRUCTED**\n- Someone made choices\n- Nothing is accidental\n- Every element has purpose\n\n**2. MEDIA USE CODES AND CONVENTIONS**\n- Camera angles\n- Music/sound effects\n- Lighting and color\n- Editing techniques\n\n**3. DIFFERENT PEOPLE INTERPRET DIFFERENTLY**\n- Based on experiences\n- Cultural background\n- Age, gender, values\n\n**4. MEDIA HAVE COMMERCIAL PURPOSES**\n- Most media wants to sell\n- Advertising revenue\n- Product placement\n\n**5. MEDIA CONTAIN VALUES AND IDEOLOGIES**\n- What's shown as 'normal'?\n- Who has power?\n- What's valued?\n\n## Media Techniques\n\n**VISUAL TECHNIQUES:**\n\n**Camera Angles:**\n- Low angle: Makes subject look powerful\n- High angle: Makes subject look weak\n- Eye level: Neutral, equal\n\n**Lighting:**\n- Bright: Positive, happy\n- Dark: Mysterious, scary\n- Contrast: Drama, conflict\n\n**Color:**\n- Warm (red, orange): Energy, passion\n- Cool (blue, green): Calm, sad\n- Black/white: Serious, classic\n\n**AUDIO TECHNIQUES:**\n\n**Music:**\n- Fast tempo: Excitement\n- Slow tempo: Sadness, calm\n- No music: Realism, tension\n\n**Sound Effects:**\n- Enhance emotion\n- Create atmosphere\n- Draw attention\n\n**EDITING TECHNIQUES:**\n\n**Pace:**\n- Quick cuts: Action, energy\n- Long shots: Calm, contemplation\n\n**Juxtaposition:**\n- Placing images together for meaning\n- Example: Luxury car + beautiful scenery\n\n## Questions for Media Analysis\n\n**1. Who created this?**\n- What's their purpose?\n\n**2. Who is the target audience?**\n- Age, gender, interests?\n\n**3. What techniques are used?**\n- Visual, audio, text?\n\n**4. What values are promoted?**\n- What's shown as good/bad?\n\n**5. What's left out?**\n- Whose voices are missing?\n\n**6. How might different people interpret this?**\n- Consider various perspectives",
                keyTerms: ["Media Literacy", "Camera Angle", "Target Audience", "Media Techniques", "Ideology"],
                examples: [
                    {
                        problem: "A commercial shows a low camera angle of a truck driving through mud. What message does this send?",
                        solution: "The truck is powerful, strong, and capable - the low angle makes it look dominant",
                        steps: ["1. Identify technique (low camera angle)", "2. Recall effect (makes subject look powerful)", "3. Connect to product (truck = powerful)"]
                    }
                ],
                practice: [
                    { text: "How might fast-paced music affect a viewer's emotions in a commercial?", space: 80 },
                    { text: "Why do advertisers choose specific target audiences?", space: 80 },
                    { text: "Find a magazine ad. What techniques does it use? Who is the target audience?", space: 100 }
                ]
            }
        ]
    },
    "Novel Study Skills": {
        title: "Analyzing Novels and Long-Form Texts",
        curriculumCode: "8e1 - Reading",
        overallExpectation: "analyze novels for literary elements, themes, and character development",
        workbook: [
            {
                lessonNumber: 1,
                lessonTitle: "Character Analysis",
                tutorial: "# Analyzing Characters in Novels\n\n## Types of Characters\n\n**PROTAGONIST**\n- Main character\n- Story centers on them\n- Usually faces conflict\n\n**ANTAGONIST**\n- Opposes protagonist\n- Creates conflict\n- Not always a 'villain'\n\n**SUPPORTING CHARACTERS**\n- Help tell the story\n- Interact with protagonist\n- May have own subplots\n\n## Character Development\n\n**STATIC CHARACTER**\n- Stays the same\n- No major changes\n- Same personality throughout\n\n**DYNAMIC CHARACTER**\n- Changes and grows\n- Learns lessons\n- Transforms by end\n\n**ROUND CHARACTER**\n- Complex, realistic\n- Multiple traits\n- Feels like real person\n\n**FLAT CHARACTER**\n- Simple, one-dimensional\n- One or two traits\n- Stereotypical\n\n## Methods of Characterization\n\n**DIRECT CHARACTERIZATION**\n- Author tells you directly\n- Example: 'Sarah was brave and kind'\n\n**INDIRECT CHARACTERIZATION (STEAL)**\n\n**S - Speech:** What they say, how they talk\n**T - Thoughts:** What they think, feel\n**E - Effect on others:** How others react to them\n**A - Actions:** What they do\n**L - Looks:** Physical appearance\n\n## Character Motivation\n\n**What drives the character?**\n- Desires and goals\n- Fears and obstacles\n- Values and beliefs\n- Past experiences\n\n**Questions to Ask:**\n- What does the character want?\n- Why do they want it?\n- What's stopping them?\n- How do they change?\n\n## Character Relationships\n\n**Types of Relationships:**\n- Family\n- Friendship\n- Romance\n- Rivalry\n- Mentor/student\n\n**Analyzing Relationships:**\n- How do characters interact?\n- How do relationships change?\n- What conflicts arise?\n- How do relationships reveal character?\n\n## Writing Character Analysis\n\n**Structure:**\n1. Introduction: Character name, role, brief description\n2. Body: Traits with evidence from text\n3. Development: How character changes\n4. Significance: Why character matters to story\n5. Conclusion: Overall impact",
                keyTerms: ["Protagonist", "Antagonist", "Dynamic Character", "Static Character", "Characterization", "STEAL"],
                examples: [
                    {
                        problem: "A character refuses to help others, but by the end saves someone's life. What type of character?",
                        solution: "Dynamic character - they change from selfish to selfless",
                        steps: ["1. Note beginning behavior (refuses to help)", "2. Note ending behavior (saves life)", "3. Character changed = dynamic"]
                    }
                ],
                practice: [
                    { text: "Choose a character from a book you've read. Describe them using STEAL", space: 100 },
                    { text: "What's the difference between a round and flat character? Give examples", space: 90 },
                    { text: "Why is character motivation important in a story?", space: 80 }
                ]
            }
        ]
    },
    "Formal Writing": {
        title: "Academic and Formal Writing Skills",
        curriculumCode: "8e2 - Writing",
        overallExpectation: "write formal texts using appropriate conventions and style",
        workbook: [
            {
                lessonNumber: 1,
                lessonTitle: "Formal vs. Informal Writing",
                tutorial: "# Formal Writing\n\n## Formal vs. Informal\n\n**FORMAL WRITING:**\n- Academic essays\n- Business letters\n- Research papers\n- Reports\n\n**INFORMAL WRITING:**\n- Emails to friends\n- Text messages\n- Personal journals\n- Social media posts\n\n## Characteristics of Formal Writing\n\n**1. TONE**\n- Serious, professional\n- Objective (not personal)\n- Respectful\n\n**2. VOCABULARY**\n- Precise, sophisticated words\n- No slang or contractions\n- Technical terms when appropriate\n\n**3. STRUCTURE**\n- Clear organization\n- Logical flow\n- Proper paragraphs\n\n**4. GRAMMAR**\n- Complete sentences\n- Correct punctuation\n- Third person (he, she, they)\n- Avoid 'I' and 'you'\n\n## Formal vs. Informal Examples\n\n**Informal:** 'The book was really good and I liked it a lot!'\n**Formal:** 'The novel demonstrates exceptional literary merit through its complex characterization.'\n\n**Informal:** 'Kids shouldn't have tons of homework.'\n**Formal:** 'Students should not be assigned excessive homework.'\n\n**Informal:** 'It's gonna be hard.'\n**Formal:** 'It will be challenging.'\n\n## Words to Avoid in Formal Writing\n\n**Contractions:**\n- Don't → do not\n- Can't → cannot\n- It's → it is\n\n**Slang/Colloquialisms:**\n- Stuff → items, things\n- Kids → children, students\n- Lots of → many, numerous\n- Get → obtain, receive\n\n**Vague Words:**\n- Good → effective, beneficial\n- Bad → detrimental, harmful\n- Big → significant, substantial\n- Really → very, extremely (or remove)\n\n## Formal Writing Structure\n\n**INTRODUCTION:**\n- Hook (formal)\n- Background\n- Thesis statement\n\n**BODY PARAGRAPHS:**\n- Topic sentence\n- Evidence and analysis\n- Transitions\n\n**CONCLUSION:**\n- Restate thesis\n- Summarize points\n- Final thought\n\n## Transition Words for Formal Writing\n\n**Addition:** Furthermore, moreover, additionally\n**Contrast:** However, nevertheless, conversely\n**Cause/Effect:** Consequently, therefore, thus\n**Example:** For instance, specifically, namely\n**Conclusion:** In conclusion, ultimately, finally",
                keyTerms: ["Formal Writing", "Tone", "Academic Writing", "Thesis Statement", "Transition Words"],
                examples: [
                    {
                        problem: "Make formal: 'Lots of kids think homework is bad'",
                        solution: "Many students believe homework is detrimental to learning",
                        steps: ["1. Replace 'lots of' with 'many'", "2. Replace 'kids' with 'students'", "3. Replace 'think' with 'believe'", "4. Replace 'bad' with 'detrimental'"]
                    }
                ],
                practice: [
                    { text: "Rewrite formally: 'I think schools should start later cuz kids are tired'", space: 80 },
                    { text: "List 5 words/phrases to avoid in formal writing and their formal alternatives", space: 100 },
                    { text: "Why is it important to use formal writing in academic essays?", space: 80 }
                ]
            }
        ]
    }
};

// Export for integration
if (typeof module !== 'undefined' && module.exports) {
    module.exports = grade8EnglishExpansion;
}
